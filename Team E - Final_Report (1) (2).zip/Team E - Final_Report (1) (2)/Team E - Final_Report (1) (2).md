<h1><center>Big Data Challenge - Team E</center></h1>

#### __How have people’s habits changed during the pandemic and what is the impact on UK Sustainability targets as a result of these changes?__

By Sarah Butterworth, Maisha Chowdhury, Sophie Kitchin, Skye Hinds, Sian Gregory

## Introduction

To mitigate the health impacts of COVID-19, the UK government is continuously adapting its response and stringency measures. The measures began on 16th March 2020 with an announcement that all unnecessary contact should cease, leading to a national lockdown on 23rd March, which included the closing of non-essential businesses and schools. As the UK population adapts to this new way of life centred around the home, new habits and perceptions may form. In this report we investigate examples of how habits have changed and how this affects the UK's Sustainability targets.

The investigation is split into two parts:

1. __Individual habits: Transportation habits and the UK's Sustainability targets.__
2. __Aggregate habits: The overall impact of the COVID-19 pandemic on businesses and how their sustainability interacted with this.__

A change in transportation habits may directly impact the UK’s 25-year environmental plan, particularly the clean air target. With a shift to working from home, a reduction in traffic may also lead to a reduction in air pollution, particularly in usually congested city areas.

We define people’s habits to go beyond that of the general population, but to also include the habits of investors and businesses. Markets across the world have been severely impacted by the pandemic, which may lead to a shift in priorities and a reduction in environmental and social investment by businesses.

To meet the environmental targets, the government must work with businesses operating in the UK to ensure best sustainable practices. During these unprecedented times, businesses must be assured that good environmental, social and governance is worth pursuing, despite the economic impact of COVID-19.

## Acknowledgment 

We would like to express special thanks to R2 Data Labs and Emergent Alliance with particular thanks to Manisha Mistry, Caroline Gorski, Alvaro Corrales Cano, Maria Ivanciu and Olya Nicholls as well as the Code First Girls team who gave us this opportunity to participate in this incredible open source project, on the topic of sustainability in a post Covid-19 world. This project helped us to improve our Python and research skills which is crucial for data science. We came to learn new things from our research and results. We really enjoyed working together, it made coding and analysis more fun and engaging. We hope to present out work to you to further tell the story of our data. We hope we delivered on your expectations and thank you once again for this special opportunity.  


### Contents
1. Environmental Sustainability Results

   a) Air Quality in UK Major Cities during the COVID-19 Lockdown Period

   b) Transport Habits During the COVID-19 Pandemic
2. Economic and ESG results

   a) Economic Impact of COVID-19 on Companies by Sector

   b) The Rise of ESG Firms

   c) ESG Resiliance & The Impact of ESG Ratings on Tech Companies During the Pandemic 

Each section outlines the data used, the preparation and exploration of the data, and the results. 

## 1) Individual habits: Transportation habits and the clean air sustainability target

The UK's lockdown period restricted movement and interaction of the population, ultimately impacting people's habits, such as consumer habits and transportation usage. The impact of these changes on the UK's sustainability targets is largely unknown, and will likely depend on the continuation of high stringency levels. 

In this section we will focus on the UK's clean air sustainability target and investigate how changes in transportation habits during the pandemic may affect this.

---

### 1. a) Air Quality in UK Major Cities during the COVID-19 Lockdown Period 

#### __Introduction__

One of the UK's sustainability targets is to reduce 5 major air pollutants by 2030, in order to halve the effects on public health. One of the 5 major air pollutants, nitrogen dioxide, is mainly produced from vehicles and the burning of fossil fuels and is well measured across the UK's Automatic Urban and Rural Network (AURN)(Air Expert Quality Group, 2004). 

The aim of this work is to identify the impact of COVID-19 stringency levels on transportation usage in the UK and consequently nitrogen oxide concentrations in major cities. 


```python
#Import libraries and make sure matplotlib is inline with notebook

%matplotlib inline
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.dates import DateFormatter
import seaborn as sns
import os
import geopandas as gp
```

#### __Description of the data__

The main dataset used for this section are the Air Quality Datasets from DEFRA and AURN. Major cities across the UK have been selected as they are predicted to be the most impacted by the change in traffic. 

The stringency dataset from Oxford University is also selected to identify any correlation with changes in nitrogen dioxide (NO2) and more stringent measures.

#### __References__:

Department for Environment, Food and Rural Affairs (2020). UK AIR: Air Information Resource. Available at: https://uk-air.defra.gov.uk/ (Accessed: 5 September 2020).

Hale, T., Webster, S. Petherick, A., Phillips, T., and Kira, B. (2020). Oxford COVID-19 Government Response Tracker, Blavatnik School of Government. Data use policy: Creative Commons Attribution CC BY standard.




```python
# Import airqual data, from UK Air DEFRA (2020) https://uk-air.defra.gov.uk/data/ Accessed: 05/09/2020https://www.bsg.ox.ac.uk/research/research-projects/coronavirus-government-response-tracker
filename = 'airqual.csv'
airqualdf = pd.read_csv(filename)
```


```python
# Import stringency from provided dataset, Coronavirus Government Response Tracker, 
#Oxford University (2020) https://www.bsg.ox.ac.uk/research/research-projects/coronavirus-government-response-tracker, Accessed: 05/09/2020
filename2 = 'D:\Sarah\Documents\Hackathon\stringency3.csv'
strdf = pd.read_csv(filename2)
```


```python
#convert dates to datetime for better plotting
airqualdf['Date'] = pd.to_datetime(airqualdf['Date'])
```


```python
#convert dates to datetime for better plotting
strdf['Date']=pd.to_datetime(strdf['Date'])
```

#### __Preparing the Data__

The AURN dataset is previewed below, and the data was cleaned and organised using mySQL. As mySQL has been selected to clean and filter data, various versions/tables of the air quality dataset are imported when required. The raw data is freely available at: https://uk-air.defra.gov.uk/data/. 

As the author does not have a background in air quality preduction, NaN values were left in the dataset, as air pollutant levels are dependent on many variables (wind direction and strength, daily temperature, congestion levels).  


```python
#checking imported data. NOTE FOR READER: Measurements are in μgm-3 

airqualdf[50:100]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Birmingham A4540 Roadside</th>
      <th>Edinburgh St Leonards</th>
      <th>Glasgow Kerbside</th>
      <th>London Marylebone Road</th>
      <th>Manchester Piccadilly</th>
      <th>Newcastle Centre</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-09-20</th>
      <td>76.0</td>
      <td>25.0</td>
      <td>279.0</td>
      <td>444.0</td>
      <td>64.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>2017-09-21</th>
      <td>99.0</td>
      <td>29.0</td>
      <td>156.0</td>
      <td>404.0</td>
      <td>47.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2017-09-22</th>
      <td>122.0</td>
      <td>24.0</td>
      <td>259.0</td>
      <td>496.0</td>
      <td>83.0</td>
      <td>55.0</td>
    </tr>
    <tr>
      <th>2017-09-23</th>
      <td>63.0</td>
      <td>20.0</td>
      <td>235.0</td>
      <td>223.0</td>
      <td>71.0</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>2017-09-24</th>
      <td>42.0</td>
      <td>30.0</td>
      <td>236.0</td>
      <td>171.0</td>
      <td>55.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>2017-09-25</th>
      <td>73.0</td>
      <td>40.0</td>
      <td>245.0</td>
      <td>201.0</td>
      <td>88.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>2017-09-26</th>
      <td>61.0</td>
      <td>28.0</td>
      <td>261.0</td>
      <td>215.0</td>
      <td>88.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>2017-09-27</th>
      <td>52.0</td>
      <td>17.0</td>
      <td>158.0</td>
      <td>363.0</td>
      <td>58.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>2017-09-28</th>
      <td>118.0</td>
      <td>20.0</td>
      <td>226.0</td>
      <td>459.0</td>
      <td>62.0</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>2017-09-29</th>
      <td>83.0</td>
      <td>13.0</td>
      <td>168.0</td>
      <td>459.0</td>
      <td>64.0</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>2017-09-30</th>
      <td>78.0</td>
      <td>25.0</td>
      <td>188.0</td>
      <td>316.0</td>
      <td>69.0</td>
      <td>58.0</td>
    </tr>
    <tr>
      <th>2017-10-01</th>
      <td>34.0</td>
      <td>14.0</td>
      <td>71.0</td>
      <td>223.0</td>
      <td>29.0</td>
      <td>52.0</td>
    </tr>
    <tr>
      <th>2017-10-02</th>
      <td>53.0</td>
      <td>15.0</td>
      <td>57.0</td>
      <td>348.0</td>
      <td>23.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>2017-10-03</th>
      <td>80.0</td>
      <td>21.0</td>
      <td>68.0</td>
      <td>234.0</td>
      <td>30.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2017-10-04</th>
      <td>63.0</td>
      <td>21.0</td>
      <td>142.0</td>
      <td>474.0</td>
      <td>42.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>2017-10-05</th>
      <td>53.0</td>
      <td>30.0</td>
      <td>124.0</td>
      <td>147.0</td>
      <td>29.0</td>
      <td>47.0</td>
    </tr>
    <tr>
      <th>2017-10-06</th>
      <td>90.0</td>
      <td>30.0</td>
      <td>201.0</td>
      <td>218.0</td>
      <td>62.0</td>
      <td>52.0</td>
    </tr>
    <tr>
      <th>2017-10-07</th>
      <td>49.0</td>
      <td>19.0</td>
      <td>95.0</td>
      <td>268.0</td>
      <td>33.0</td>
      <td>36.0</td>
    </tr>
    <tr>
      <th>2017-10-08</th>
      <td>56.0</td>
      <td>16.0</td>
      <td>97.0</td>
      <td>193.0</td>
      <td>35.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>2017-10-09</th>
      <td>101.0</td>
      <td>14.0</td>
      <td>106.0</td>
      <td>457.0</td>
      <td>60.0</td>
      <td>47.0</td>
    </tr>
    <tr>
      <th>2017-10-10</th>
      <td>68.0</td>
      <td>14.0</td>
      <td>93.0</td>
      <td>382.0</td>
      <td>50.0</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>2017-10-11</th>
      <td>47.0</td>
      <td>18.0</td>
      <td>110.0</td>
      <td>396.0</td>
      <td>40.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>2017-10-12</th>
      <td>101.0</td>
      <td>11.0</td>
      <td>124.0</td>
      <td>548.0</td>
      <td>59.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>2017-10-13</th>
      <td>56.0</td>
      <td>10.0</td>
      <td>92.0</td>
      <td>396.0</td>
      <td>55.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>2017-10-14</th>
      <td>65.0</td>
      <td>14.0</td>
      <td>160.0</td>
      <td>285.0</td>
      <td>52.0</td>
      <td>36.0</td>
    </tr>
    <tr>
      <th>2017-10-15</th>
      <td>66.0</td>
      <td>9.0</td>
      <td>79.0</td>
      <td>247.0</td>
      <td>32.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>2017-10-16</th>
      <td>53.0</td>
      <td>16.0</td>
      <td>195.0</td>
      <td>303.0</td>
      <td>43.0</td>
      <td>56.0</td>
    </tr>
    <tr>
      <th>2017-10-17</th>
      <td>70.0</td>
      <td>17.0</td>
      <td>105.0</td>
      <td>469.0</td>
      <td>46.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>2017-10-18</th>
      <td>77.0</td>
      <td>14.0</td>
      <td>297.0</td>
      <td>213.0</td>
      <td>107.0</td>
      <td>41.0</td>
    </tr>
    <tr>
      <th>2017-10-19</th>
      <td>88.0</td>
      <td>29.0</td>
      <td>284.0</td>
      <td>319.0</td>
      <td>100.0</td>
      <td>55.0</td>
    </tr>
    <tr>
      <th>2017-10-20</th>
      <td>78.0</td>
      <td>38.0</td>
      <td>268.0</td>
      <td>424.0</td>
      <td>64.0</td>
      <td>63.0</td>
    </tr>
    <tr>
      <th>2017-10-21</th>
      <td>35.0</td>
      <td>25.0</td>
      <td>211.0</td>
      <td>200.0</td>
      <td>29.0</td>
      <td>34.0</td>
    </tr>
    <tr>
      <th>2017-10-22</th>
      <td>36.0</td>
      <td>19.0</td>
      <td>88.0</td>
      <td>181.0</td>
      <td>23.0</td>
      <td>23.0</td>
    </tr>
    <tr>
      <th>2017-10-23</th>
      <td>102.0</td>
      <td>21.0</td>
      <td>178.0</td>
      <td>412.0</td>
      <td>76.0</td>
      <td>61.0</td>
    </tr>
    <tr>
      <th>2017-10-24</th>
      <td>60.0</td>
      <td>17.0</td>
      <td>162.0</td>
      <td>338.0</td>
      <td>59.0</td>
      <td>49.0</td>
    </tr>
    <tr>
      <th>2017-10-25</th>
      <td>121.0</td>
      <td>12.0</td>
      <td>73.0</td>
      <td>412.0</td>
      <td>62.0</td>
      <td>54.0</td>
    </tr>
    <tr>
      <th>2017-10-26</th>
      <td>156.0</td>
      <td>35.0</td>
      <td>127.0</td>
      <td>377.0</td>
      <td>79.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>2017-10-27</th>
      <td>131.0</td>
      <td>40.0</td>
      <td>186.0</td>
      <td>203.0</td>
      <td>158.0</td>
      <td>61.0</td>
    </tr>
    <tr>
      <th>2017-10-28</th>
      <td>65.0</td>
      <td>14.0</td>
      <td>67.0</td>
      <td>316.0</td>
      <td>34.0</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>2017-10-29</th>
      <td>37.0</td>
      <td>44.0</td>
      <td>246.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>2017-10-30</th>
      <td>157.0</td>
      <td>55.0</td>
      <td>322.0</td>
      <td>259.0</td>
      <td>153.0</td>
      <td>74.0</td>
    </tr>
    <tr>
      <th>2017-10-31</th>
      <td>126.0</td>
      <td>13.0</td>
      <td>87.0</td>
      <td>589.0</td>
      <td>102.0</td>
      <td>61.0</td>
    </tr>
    <tr>
      <th>2017-11-01</th>
      <td>219.0</td>
      <td>18.0</td>
      <td>106.0</td>
      <td>590.0</td>
      <td>115.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>2017-11-02</th>
      <td>179.0</td>
      <td>62.0</td>
      <td>347.0</td>
      <td>425.0</td>
      <td>90.0</td>
      <td>74.0</td>
    </tr>
    <tr>
      <th>2017-11-03</th>
      <td>180.0</td>
      <td>17.0</td>
      <td>154.0</td>
      <td>550.0</td>
      <td>99.0</td>
      <td>91.0</td>
    </tr>
    <tr>
      <th>2017-11-04</th>
      <td>77.0</td>
      <td>16.0</td>
      <td>159.0</td>
      <td>214.0</td>
      <td>47.0</td>
      <td>55.0</td>
    </tr>
    <tr>
      <th>2017-11-05</th>
      <td>78.0</td>
      <td>42.0</td>
      <td>202.0</td>
      <td>150.0</td>
      <td>95.0</td>
      <td>51.0</td>
    </tr>
    <tr>
      <th>2017-11-06</th>
      <td>144.0</td>
      <td>25.0</td>
      <td>261.0</td>
      <td>506.0</td>
      <td>112.0</td>
      <td>87.0</td>
    </tr>
    <tr>
      <th>2017-11-07</th>
      <td>104.0</td>
      <td>45.0</td>
      <td>206.0</td>
      <td>382.0</td>
      <td>54.0</td>
      <td>69.0</td>
    </tr>
    <tr>
      <th>2017-11-08</th>
      <td>186.0</td>
      <td>37.0</td>
      <td>311.0</td>
      <td>177.0</td>
      <td>217.0</td>
      <td>62.0</td>
    </tr>
  </tbody>
</table>
</div>



#### __Exploring the Data__

Data was selected for the past 3 years to identify any seasonal and general trends. 

Data was used to provide summary statistics and to plot time series graphs. Time series graphs were the best way to explore the data.

#### __Results: summary statistics and plots__
Natural fluctuations throughout the year, where NO2 levels are lower during the late-spring and summer months. This is likely due to higher temperatures, lower wind speeds and atmospheric chemistry.  
Can see a decrease in NO2 in major cities after lockdown, but this may in part be due to natural seasonal fluctuations. London and Glasgow show the most abrupt change in NO2 levels. 


```python
#Set Date to index to allow exploration
airqualdf.set_index('Date', inplace=True)
```


```python
#Lets see how averages change over time and save this as 'b' so we can refer to it later.
b = airqualdf.resample('M').mean()
```


```python
#Let's select for April months, as April 2020 is a month of high stringency. Let's keep this data and store it. 
c = b.loc[['2018-04-30','2019-04-30','2020-04-30'],:]
```


```python
#Let's check that it's worked! NOTE FOR READER: Measurements are in μgm-3 
c
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Birmingham A4540 Roadside</th>
      <th>Edinburgh St Leonards</th>
      <th>Glasgow Kerbside</th>
      <th>London Marylebone Road</th>
      <th>Manchester Piccadilly</th>
      <th>Newcastle Centre</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-04-30</th>
      <td>56.133333</td>
      <td>19.000000</td>
      <td>204.366667</td>
      <td>262.066667</td>
      <td>52.100000</td>
      <td>42.692308</td>
    </tr>
    <tr>
      <th>2019-04-30</th>
      <td>44.200000</td>
      <td>22.766667</td>
      <td>201.033333</td>
      <td>130.833333</td>
      <td>53.666667</td>
      <td>38.200000</td>
    </tr>
    <tr>
      <th>2020-04-30</th>
      <td>31.944444</td>
      <td>11.533333</td>
      <td>30.931034</td>
      <td>46.000000</td>
      <td>21.900000</td>
      <td>16.800000</td>
    </tr>
  </tbody>
</table>
</div>



>We can see that each city reduced NOx between 2018 and 2019, as well as between 2019 and 2020. This is likely a downwards trend over time as the UK increases its air quality standards. Let's use Tableau to visualise... 



![Tableaupic.png](attachment:c436a123-0999-42f2-b1bc-9f78ea4c674f.png)


```python
#Declaring variables for easy plotting

date = airqualdf.loc[:, 'Date'].values
birmingham = airqualdf.loc[:, 'Birmingham A4540 Roadside'].values
edinburgh = airqualdf.loc[:, 'Edinburgh St Leonards'].values
glasgow = airqualdf.loc[:, 'Glasgow Kerbside'].values
london = airqualdf.loc[:, 'London Marylebone Road'].values
manchester = airqualdf.loc[:, 'Manchester Piccadilly'].values
newcastle = airqualdf.loc[:, 'Newcastle Centre'].values
```


```python
#Date formatting for cleaner time series axes 

years = mdates.YearLocator()   # every year
months = mdates.MonthLocator()  # every month
days = mdates.DayLocator() 
years_fmt = mdates.DateFormatter('%Y')
months_fmt = mdates.DateFormatter('%M')
```


```python
#Plotting the 2017-2020 datasets available for NOx for major cities 

fig, (ax1, ax2, ax3, ax4, ax5, ax6) = plt.subplots(nrows = 6, ncols=1, figsize=(15,25))

fig.text(0.5, -0.02, 'Years', ha='center', fontsize = 15)
fig.text(-0.05, 0.5, 'Nitrogen oxide as nitrogen dioxide µgm-3', va='center', rotation='vertical', fontsize = 18)

ax1.plot(date, birmingham)
ax1.set_title('Birmingham', fontsize = 18)
ax1.xaxis.set_major_locator(years)
ax1.xaxis.set_major_formatter(years_fmt)
ax1.xaxis.set_minor_locator(months)
ax1.tick_params(axis='x', labelsize=10)
xposition = [pd.to_datetime('2020-03-16')]
for xc in xposition:
    ax1.axvline(x=xc, color='r', linestyle='--')
    ax1.text('2020-02-28',300,'UK Lockdown',rotation=90, fontsize = 15)


ax2.plot(date, edinburgh)
ax2.set_title('Edinburgh', fontsize = 18)
ax2.xaxis.set_major_locator(years)
ax2.xaxis.set_major_formatter(years_fmt)
ax2.xaxis.set_minor_locator(months)
xposition = [pd.to_datetime('2020-03-15')]
for xc in xposition:
    ax2.axvline(x=xc, color='r', linestyle='--')

ax3.plot(date, glasgow)
ax3.set_title('Glasgow', fontsize = 18)
ax3.xaxis.set_major_locator(years)
ax3.xaxis.set_major_formatter(years_fmt)
ax3.xaxis.set_minor_locator(months)
xposition = [pd.to_datetime('2020-03-15')]
for xc in xposition:
    ax3.axvline(x=xc, color='r', linestyle='--')

ax4.plot(date, london)
ax4.set_title('London', fontsize = 18)
ax4.xaxis.set_major_locator(years)
ax4.xaxis.set_major_formatter(years_fmt)
ax4.xaxis.set_minor_locator(months)
xposition = [pd.to_datetime('2020-03-15')]
for xc in xposition:
    ax4.axvline(x=xc, color='r', linestyle='--')
    
ax5.plot(date, manchester)
ax5.set_title('Manchester', fontsize = 18)
ax5.xaxis.set_major_locator(years)
ax5.xaxis.set_major_formatter(years_fmt)
ax5.xaxis.set_minor_locator(months)
xposition = [pd.to_datetime('2020-03-15')]
for xc in xposition:
    ax5.axvline(x=xc, color='r', linestyle='--')
    
ax6.plot(date, newcastle)
ax6.set_title('Newcastle', fontsize = 18)
ax6.xaxis.set_major_locator(years)
ax6.xaxis.set_major_formatter(years_fmt)
ax6.xaxis.set_minor_locator(months)
xposition = [pd.to_datetime('2020-03-15')]
for xc in xposition:
    ax6.axvline(x=xc, color='r', linestyle='--')
plt.tight_layout()
```


![png](output_25_0.png)



```python
#reading in stringency CSV - created in mySQL 
filename3 = 'D:/Sarah/Documents/Hackathon/stringency3.csv'
strdf = pd.read_csv(filename3)
```


```python
#convert dates to datetime for better plotting
strdf['Date'] = pd.to_datetime(strdf['Date'])
```


```python
#storing variables for ease 
date2 = strdf.loc[:, 'Date'].values
birmingham2 = strdf.loc[:, 'Birmingham A4540 Roadside'].values
edinburgh2 = strdf.loc[:, 'Edinburgh St Leonards'].values
glasgow2 = strdf.loc[:, 'Glasgow Kerbside'].values
london2 = strdf.loc[:, 'London Marylebone Road'].values
manchester2 = strdf.loc[:, 'Manchester Piccadilly'].values
newcastle2 = strdf.loc[:, 'Newcastle Centre'].values
stringency = strdf.loc[:,'Stringency'].values

```


```python
#plotting NOx concentrations vs stringency
fig, ax = plt.subplots()
ax.plot(date2, glasgow2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('Glasgow Kerbside')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()

fig, ax = plt.subplots()
ax.plot(date2, london2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('London Marylebone Road')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()

fig, ax = plt.subplots()
ax.plot(date2, manchester2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('Manchester Piccadilly')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()

fig, ax = plt.subplots()
ax.plot(date2, newcastle2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('Newcastle Centre')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()


fig, ax = plt.subplots()
ax.plot(date2, edinburgh2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('Edinburgh (St Leonards)')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()

fig, ax = plt.subplots()
ax.plot(date2, birmingham2)
plt.xlabel ('Date')
plt.ylabel ('Nitrogen oxide as nitrogen dioxide µgm-3')
plt.title ('Birmingham A4540 Roadside')
plt.style.use('seaborn')
ax.grid(False)

ax2 = ax.twinx()
ax2.plot(date2, stringency,color ="red")
ax2.set_ylabel("Stringency Index")
plt.show()

# format the ticks
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(DateFormatter('%b'))
plt.show()
```


![png](output_29_0.png)



![png](output_29_1.png)



![png](output_29_2.png)



![png](output_29_3.png)



![png](output_29_4.png)



![png](output_29_5.png)


When comparing NOx concentrations with stringency, it can be seen that there is some correlation between a high stringency index and low NOx concentrations. However, some of this may be attributed to higher temperatures and seasonal fluctuations. A sudden drop in NOx levels is particularly noticeable in Glasgow and London. 

#### __Results: In-depth analysis - using FacebookProphet to predict NOx without lockdown__

It seems to appear from the above analysis that lockdown impacted NOx concentrations in the months of March-August 2020. However, as NOx appears to reduce year on year, it is unclear how much higher the NOx concentrations would have been without lockdown restrictions. In order to gain an estimate, FBProphet was trialled as a predictive tool, due to its ability to account for seasonality. 

London was selected as a city to trial Prophet, due to having the most complete dataset for the past 5 years. London also has a much higher population (8.9 million) in comparison to the rest of the UK cities, alongside being a tourist destination. Therefore, it is much more likely to be impacted by people's travelling habits. 

Source: https://facebook.github.io/prophet/docs/quick_start.html 


```python
#import data. FBProphet requires specific column names. London.csv is data up to March 2020. LondonActual.csv is measured site data from March 2020. 
df = pd.read_csv('london.csv')
df2 = pd.read_csv('londonactual.csv')
```


```python
#make sure in date time
df['ds'] = pd.to_datetime(df['ds'])
df2['ds'] = pd.to_datetime(df2['ds'])
```


```python
#Prophet won't work with NA. 
df.dropna(inplace= True)
```


```python
m = Prophet()
```


```python
#Run prophet on data
m.fit(df)
```

    INFO:fbprophet:Disabling daily seasonality. Run prophet with daily_seasonality=True to override this.
    D:\Program Files (x86)\Anaconda\lib\site-packages\pystan\misc.py:399: FutureWarning: Conversion of the second argument of issubdtype from `float` to `np.floating` is deprecated. In future, it will be treated as `np.float64 == np.dtype(float).type`.
      elif np.issubdtype(np.asarray(v).dtype, float):





    <fbprophet.forecaster.Prophet at 0x228f16c9f88>




```python
#predict and ask for preview 
forecast = m.predict(future)
forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ds</th>
      <th>yhat</th>
      <th>yhat_lower</th>
      <th>yhat_upper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2144</th>
      <td>2021-02-25</td>
      <td>168.785724</td>
      <td>36.581839</td>
      <td>307.371554</td>
    </tr>
    <tr>
      <th>2145</th>
      <td>2021-02-26</td>
      <td>153.442659</td>
      <td>16.285096</td>
      <td>295.944055</td>
    </tr>
    <tr>
      <th>2146</th>
      <td>2021-02-27</td>
      <td>74.757415</td>
      <td>-65.591769</td>
      <td>201.187099</td>
    </tr>
    <tr>
      <th>2147</th>
      <td>2021-02-28</td>
      <td>35.808380</td>
      <td>-95.647930</td>
      <td>164.828554</td>
    </tr>
    <tr>
      <th>2148</th>
      <td>2021-03-01</td>
      <td>108.273241</td>
      <td>-18.049304</td>
      <td>245.090889</td>
    </tr>
  </tbody>
</table>
</div>




```python
#plot, where y = NOx as nitrogen dioxide in ugm-3 and ds = time 
fig1 = m.plot(forecast)
```


![png](output_39_0.png)



```python
#ask what components are causing variability 
fig2 = m.plot_components(forecast)
```


![png](output_40_0.png)


As previously noted from the data plots above, there tends to be lower NOx over summer months, which FBProphet has also identified. We can also see that NOx concentrations tend to be highest through Monday - Friday - the working week. NOx concentrations show a general decrease over time, which Prophet has predicted to continue into 2020 and 2021.

Next, we will select the predicted values from March 2020 - August 2020 and match these with the actual measured values.


```python
#selection of forecast data 
ncforecast = forecast[1783:1954]
```


```python
#preview data 
ncforecast
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ds</th>
      <th>trend</th>
      <th>yhat_lower</th>
      <th>yhat_upper</th>
      <th>trend_lower</th>
      <th>trend_upper</th>
      <th>additive_terms</th>
      <th>additive_terms_lower</th>
      <th>additive_terms_upper</th>
      <th>weekly</th>
      <th>weekly_lower</th>
      <th>weekly_upper</th>
      <th>yearly</th>
      <th>yearly_lower</th>
      <th>yearly_upper</th>
      <th>multiplicative_terms</th>
      <th>multiplicative_terms_lower</th>
      <th>multiplicative_terms_upper</th>
      <th>yhat</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1783</th>
      <td>2020-03-01</td>
      <td>138.025555</td>
      <td>-45.494410</td>
      <td>227.469940</td>
      <td>138.025555</td>
      <td>138.025555</td>
      <td>-47.182010</td>
      <td>-47.182010</td>
      <td>-47.182010</td>
      <td>-82.869253</td>
      <td>-82.869253</td>
      <td>-82.869253</td>
      <td>35.687243</td>
      <td>35.687243</td>
      <td>35.687243</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>90.843545</td>
    </tr>
    <tr>
      <th>1784</th>
      <td>2020-03-02</td>
      <td>137.860847</td>
      <td>32.780904</td>
      <td>292.366196</td>
      <td>137.860847</td>
      <td>137.860847</td>
      <td>24.461348</td>
      <td>24.461348</td>
      <td>24.461348</td>
      <td>-6.406932</td>
      <td>-6.406932</td>
      <td>-6.406932</td>
      <td>30.868280</td>
      <td>30.868280</td>
      <td>30.868280</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>162.322195</td>
    </tr>
    <tr>
      <th>1785</th>
      <td>2020-03-03</td>
      <td>137.696140</td>
      <td>66.215595</td>
      <td>332.947039</td>
      <td>137.696140</td>
      <td>137.696140</td>
      <td>58.798171</td>
      <td>58.798171</td>
      <td>58.798171</td>
      <td>33.443653</td>
      <td>33.443653</td>
      <td>33.443653</td>
      <td>25.354518</td>
      <td>25.354518</td>
      <td>25.354518</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>196.494310</td>
    </tr>
    <tr>
      <th>1786</th>
      <td>2020-03-04</td>
      <td>137.531432</td>
      <td>51.404146</td>
      <td>321.395806</td>
      <td>137.531432</td>
      <td>137.531432</td>
      <td>49.415831</td>
      <td>49.415831</td>
      <td>49.415831</td>
      <td>30.164752</td>
      <td>30.164752</td>
      <td>30.164752</td>
      <td>19.251080</td>
      <td>19.251080</td>
      <td>19.251080</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>186.947263</td>
    </tr>
    <tr>
      <th>1787</th>
      <td>2020-03-05</td>
      <td>137.366724</td>
      <td>59.241221</td>
      <td>316.228064</td>
      <td>137.366724</td>
      <td>137.366724</td>
      <td>56.038229</td>
      <td>56.038229</td>
      <td>56.038229</td>
      <td>43.358577</td>
      <td>43.358577</td>
      <td>43.358577</td>
      <td>12.679652</td>
      <td>12.679652</td>
      <td>12.679652</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>193.404953</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1949</th>
      <td>2020-08-14</td>
      <td>110.684076</td>
      <td>-30.063314</td>
      <td>234.793675</td>
      <td>109.439748</td>
      <td>111.913890</td>
      <td>-8.646637</td>
      <td>-8.646637</td>
      <td>-8.646637</td>
      <td>29.370994</td>
      <td>29.370994</td>
      <td>29.370994</td>
      <td>-38.017632</td>
      <td>-38.017632</td>
      <td>-38.017632</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>102.037438</td>
    </tr>
    <tr>
      <th>1950</th>
      <td>2020-08-15</td>
      <td>110.519368</td>
      <td>-102.609870</td>
      <td>163.186439</td>
      <td>109.260859</td>
      <td>111.758237</td>
      <td>-84.412751</td>
      <td>-84.412751</td>
      <td>-84.412751</td>
      <td>-47.061790</td>
      <td>-47.061790</td>
      <td>-47.061790</td>
      <td>-37.350961</td>
      <td>-37.350961</td>
      <td>-37.350961</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>26.106617</td>
    </tr>
    <tr>
      <th>1951</th>
      <td>2020-08-16</td>
      <td>110.354660</td>
      <td>-130.026804</td>
      <td>126.567566</td>
      <td>109.083352</td>
      <td>111.602584</td>
      <td>-119.382436</td>
      <td>-119.382436</td>
      <td>-119.382436</td>
      <td>-82.869253</td>
      <td>-82.869253</td>
      <td>-82.869253</td>
      <td>-36.513182</td>
      <td>-36.513182</td>
      <td>-36.513182</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-9.027775</td>
    </tr>
    <tr>
      <th>1952</th>
      <td>2020-08-17</td>
      <td>110.189953</td>
      <td>-70.665471</td>
      <td>194.818530</td>
      <td>108.906962</td>
      <td>111.452712</td>
      <td>-41.959303</td>
      <td>-41.959303</td>
      <td>-41.959303</td>
      <td>-6.406932</td>
      <td>-6.406932</td>
      <td>-6.406932</td>
      <td>-35.552371</td>
      <td>-35.552371</td>
      <td>-35.552371</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>68.230649</td>
    </tr>
    <tr>
      <th>1953</th>
      <td>2020-08-18</td>
      <td>110.025245</td>
      <td>-18.568063</td>
      <td>248.202039</td>
      <td>108.730573</td>
      <td>111.308242</td>
      <td>-1.074016</td>
      <td>-1.074016</td>
      <td>-1.074016</td>
      <td>33.443653</td>
      <td>33.443653</td>
      <td>33.443653</td>
      <td>-34.517669</td>
      <td>-34.517669</td>
      <td>-34.517669</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>108.951229</td>
    </tr>
  </tbody>
</table>
<p>171 rows × 19 columns</p>
</div>




```python
#plotting of forecast data against real measured data. 

x = ncforecast['ds']
y = ncforecast['yhat']
x2 = df2['ds']
y2 = df2['y']

plt.plot(x,y, label ='FacebookProphet Prediction')
plt.plot(x2,y2, label = 'Actual Measurement')
plt.style.use('seaborn')
plt.title("FBProphet predicted NOx measurements vs real measurements for lockdown period - London Marylebone Road")
plt.xlabel('Date')
plt.ylabel('NOx as Nitrogen Dioxide μgm-3')
plt.legend()
plt.show()
```


![png](output_44_0.png)


We can see from the data above that Prophet is good at predicting daily seasonality (location of troughs and peaks). We can see that Prophet predicted much higher NOx concentrations for London, suggesting that stringency measures did indeed contribute slightly to decreased NOx concentrations. 

This is however, a simplification of a highly complex system, which would require a dedicated algorithm and several datasets which are currently unaccessible or incomplete. 

#### __Conclusions and recommendations__

Measured NOx concentrations in major UK cities are decreasing year on year, as the UK moves towards its sustainability targets. NOx concentrations also tend to fluctuate seasonally throughout the year, decreasing throughout the late Spring and Summer months. 

Despite seasonal fluctuations, there seems to be a correlation between the steep drop in NOx concentrations and the steep increase in stringency levels in March 2020, and is particularly evident in Glasgow and London.

As detailed in the previous section, the sudden reduction in NOx is likely due to a sudden change in people's travelling habits, associated with a move to studying and working from home. The closure of non-essential businesses and social distancing regulations likely contributed to this change, providing less reasons for travel into cities. 

However, whether these changes in habits are permanent are unknown, and are largely dependent on how long restrictions associated with the pandemic remain in place. The following section will address how transportation and travelling habits have changed, and provide further insight into the permanence of these changes. 

Predictions from FacebookProphet suggest that NOx would have been higher based on previous data, further supporting the hypothesis that lockdown habits impacted air quality. However, air chemistry is not straight forward to predict, and ideally a dedicated algorithm would be produced to take into account other atmospheric variables, such as wind strength. All variables should be defined and also must be readily available as datasets. Perhaps modelling one city (e.g. London) with well quantified air quality data would allow for the validation of FacebookProphet predictions.  

---

### 1. b) Transport habits during the COVID-19 pandemic

#### __Introduction__

This section will explore the changes to how people have been travelling since the start of the COVID-19 pandemic to date (March to September 2020).

- How have people been travelling during the pandemic?
- Where are people spending their time and how might that impact transport usage?
- Will these changes lead to a longer term change of habit?

#### b) i) Changes in use of different modes of transport during the COVID-19 pandemic

#### __Description of the data__

The dataset shows percentage change in transport usage by mode between a day before the pandemic and during. The data is provided daily.

#### __References__:

Department for Transport (2020). _Transport use during the coronavirus (COVID-19) pandemic._ Available at: https://www.gov.uk/government/statistics/transport-use-during-the-coronavirus-covid-19-pandemic (Accessed: 16 September 2020)

##### Notes about the data
- The data is presented each day as % change against a base day on an equivalent week. The base comparison dates vary for different modes of transport.
- Fluctuations occur due to weekends and bank holidays.
- The base date for the cycling figures is the first week of March, so seasonal patterns in cycling should be taken into account.

#### __Preparing the Data__

>Import relevant libraries and load the dataset.


```python
import pandas as pd
import numpy as np
```


```python
transport = pd.read_csv("data/COVID-19-transport-use-statistics-data.csv")
```

>Rename the columns and set the correct data types.


```python
# Rename columns.
transport.rename(columns = {'Date1\n (weekends and bank holidays in grey)':'Date','Cars2':'Cars','Light Commercial Vehicles2':'Light Commercial Vehicles','Heavy Goods Vehicles2':'Heavy Goods Vehicles','All motor vehicles2':'All motor vehicles','National Rail3,4':'National Rail','Transport for London Tube5':'Transport for London Tube','Transport for London Bus5,7':'Transport for London Bus','Bus (excl. London)6,8,9':'Bus (excl. London)','Cycling10,11':'Cycling'},inplace=True)
```


```python
# Change the Date column to type date
Date_clean = pd.to_datetime(transport['Date'].astype('str'), format='%d/%m/%Y')
transport = transport.assign(Date = Date_clean)
```


```python
# Create list of columns that represent the transport modes
transport_mode = []
for x in transport.columns:
    if x != 'Date':
        transport_mode.append(x)
```


```python
# Remove the % from data values. Remove references after '%'. Remove the 'r' infront of values which have been revised. Set empty values to NaN.
for x in transport_mode:
    transport[x] = transport[x].str.split('%').str[0]
    transport[x] = transport[x].str.replace(r'%','')
    transport[x] = transport[x].str.replace(r'r ','')
    transport[x] = transport[x].astype(str).replace(r'..',np.nan,regex=False)
```

>Drop days with a data point that is 'provisional' (indicated by 'p').


```python
print(transport.shape)
transport = transport.drop(transport[transport['National Rail'].str.match('p ')].index)
print(transport.shape)
```

    (198, 10)
    (190, 10)


>Convert values to numeric data type.


```python
for x in transport_mode:
    transport[x]=transport[x].astype(str).astype(float)
transport.dtypes
```




    Date                         datetime64[ns]
    Cars                                float64
    Light Commercial Vehicles           float64
    Heavy Goods Vehicles                float64
    All motor vehicles                  float64
    National Rail                       float64
    Transport for London Tube           float64
    Transport for London Bus            float64
    Bus (excl. London)                  float64
    Cycling                             float64
    dtype: object



>Shift % values down by 100 to represent percentage increase and decrease around 0.


```python
transport_shift = transport
for x in transport_mode:
    transport_shift[x] = transport[x] - 100
```

>Export dataframe to excel file for visualisation.


```python
transport_shift.to_excel('data/COVID-19-transport-use-statistics-data-cleaned-shift.xlsx')
```

>Find the monthly average of each mode of transport, and an average for public transport.


```python
transport['Month'] = pd.DatetimeIndex(transport.loc[:,'Date']).month
```


```python
transport_month_average =transport.groupby([transport['Month']]).mean()
```


```python
transport_month_average['Average Public Transport'] = transport_public_month[['National Rail','Transport for London Tube','Transport for London Bus','Bus (excl. London)']].mean(axis=1)
```


```python
transport_month_average
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cars</th>
      <th>Light Commercial Vehicles</th>
      <th>Heavy Goods Vehicles</th>
      <th>All motor vehicles</th>
      <th>National Rail</th>
      <th>Transport for London Tube</th>
      <th>Transport for London Bus</th>
      <th>Bus (excl. London)</th>
      <th>Cycling</th>
      <th>Average Public Transport</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>-23.161290</td>
      <td>-16.096774</td>
      <td>-4.838710</td>
      <td>-20.935484</td>
      <td>-38.193548</td>
      <td>-49.612903</td>
      <td>-36.774194</td>
      <td>-47.347826</td>
      <td>1.416667</td>
      <td>-42.982118</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-66.766667</td>
      <td>-59.233333</td>
      <td>-38.133333</td>
      <td>-63.833333</td>
      <td>-95.433333</td>
      <td>-95.300000</td>
      <td>-82.944444</td>
      <td>-88.666667</td>
      <td>73.366667</td>
      <td>-90.586111</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-50.419355</td>
      <td>-39.774194</td>
      <td>-24.967742</td>
      <td>-46.838710</td>
      <td>-94.032258</td>
      <td>-93.548387</td>
      <td>NaN</td>
      <td>-86.233333</td>
      <td>115.580645</td>
      <td>-91.271326</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-31.033333</td>
      <td>-17.900000</td>
      <td>-8.833333</td>
      <td>-27.133333</td>
      <td>-86.700000</td>
      <td>-87.266667</td>
      <td>-68.545455</td>
      <td>-79.633333</td>
      <td>67.733333</td>
      <td>-80.536364</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-16.741935</td>
      <td>-4.677419</td>
      <td>-0.612903</td>
      <td>-13.419355</td>
      <td>-76.129032</td>
      <td>-77.516129</td>
      <td>-56.935484</td>
      <td>-67.354839</td>
      <td>46.677419</td>
      <td>-69.483871</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-9.290323</td>
      <td>0.741935</td>
      <td>0.193548</td>
      <td>-6.709677</td>
      <td>-65.516129</td>
      <td>-68.322581</td>
      <td>-45.806452</td>
      <td>-56.870968</td>
      <td>28.451613</td>
      <td>-59.129032</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-6.833333</td>
      <td>4.500000</td>
      <td>7.000000</td>
      <td>-4.000000</td>
      <td>-62.833333</td>
      <td>-63.500000</td>
      <td>-44.333333</td>
      <td>-49.833333</td>
      <td>34.166667</td>
      <td>-55.125000</td>
    </tr>
  </tbody>
</table>
</div>



#### __Results: Changes in use of different modes of transport during the COVID-19 pandemic__

>__Key findings__:
>1. Private and commercial road vehicle use dropped significantly during the first three months of the pandemic, but has risen to just below base levels since.
>2. Cycling has increased overall but fluctuates with the weather.
>3. Public transport is well below normal usage levels. Trips were 90% below base levels in April 2020 and 59% below in August.

> The use of __cars, heavy goods vehicles and light commercial vehicles__ dropped to below 50% of normal usage in the first weeks after lockdown. With the easing of lockdown, the use of cars has moved to just below normal levels. In particular, on weekends car usage is fluctuating around the base level. Commercial vehicles have been around normal levels since the start of July.

![image.png](attachment:89330ddd-25e7-42c9-9c78-8a87a5cc3d7f.png)

>__Cycling__ has been above normal levels since the start of lockdown, with peaks of more than 250% above base levels during the summer. These levels fluctuate due to changes in the weather (they are compared to a base week in March) along with possible data quality issues.

![image.png](attachment:ffe6fb0e-f1b3-4f05-ace2-6b08690d97de.png)

>All __Public transport__ use dropped to over 90% below usual levels after lockdown (April average). It has risen again but remains at less than 50% of the usual amount. It seems that National Rail and the London Tube have seen the biggest reduction, between 65 and 70% less than base levels in August. TfL buses were 46% and non-London buses were 57% below base levels in August.

![image.png](attachment:4fc1361e-dbdb-4282-87d5-320866e3aba3.png)

#### b) ii) __Mobility patterns during the COVID-19 pandemic__

In this section we will investigate how people's mobility patterns have changed from March to September 2020. _Where_ people are travelling can then help us understand the reasons for the changes in _how_ people are travelling. From here we can discuss whether these changes reflect a longer term change of habit or a reaction to government guidelines.

#### __Description of the data__

The Google Community Mobility Reports dataset shows the percentage change of people visiting different places, split into categories. This is based on a comparison with the median value each day from the 5‑week period Jan 3 – Feb 6, 2020.

All categories measure a change in total visitors, apart from the Residential category which shows a change in duration.

Google (2020). _COVID-10 Community Mobility Reports - Regions CSV_ Available at: https://www.google.com/covid19/mobility/ (Accessed: 12 September 2020)

##### Notes about the data
- The baseline values do not account for seasonality, so some differences may be a natural increase or decrease due to the weather.
- Fluctuations occur due to bank holidays.
- Values are calculated based on data from users who have opted-in to Location History for their Google Account. Therefore the data is calculated from a sample of the population and may not represent the actual movement completely.
- Where the data did not meet quality and privacy thresholds, it has been left empy. 
- Google updated the way they calculate changes for Groceries & pharmacy, Retail & recreation, Transit stations, and Parks categories. For regions published before May 2020, the data may contain a consistent shift either up or down that starts between April 11–18, 2020.

#### __Preparing the Data__

>Import relevant libraries and load the dataset.


```python
import pandas as pd
import numpy as np
```


```python
mobility = pd.read_csv("data/2020_GB_Region_Mobility_Report.csv")
```

>Rename the columns and set the correct data types.


```python
# Rename columns.
mobility.rename(columns = {'date':'Date','retail_and_recreation_percent_change_from_baseline':'Retail and Recreation','grocery_and_pharmacy_percent_change_from_baseline':'Grocery and Pharmacy','parks_percent_change_from_baseline':'Parks','transit_stations_percent_change_from_baseline':'Transit Stations','workplaces_percent_change_from_baseline':'Workplaces','residential_percent_change_from_baseline':'Residential'},inplace=True)
```


```python
# Change the Date column to type date
Date_clean_1 = pd.to_datetime(mobility['Date'].astype('str'), format='%Y-%m-%d')
```


```python
Date_clean_2 = pd.DatetimeIndex(Date_clean_1)
```


```python
mobility = mobility.assign(Date = Date_clean_2)
```

##### Create new dataframe with just the United Kingdom aggregated data.

>Drop rows which provide the region breakdown and keep only the overall UK data.


```python
mobility_uk = mobility[mobility['sub_region_1'].isnull()]
```

>Drop irrelevant columns.


```python
mobility_uk = mobility_uk.drop(['sub_region_1','sub_region_2','metro_area','iso_3166_2_code','census_fips_code'],axis=1)
```

>Find the average for each category over the first two weeks from March 23rd.


```python
mobility_uk_first_two_weeks = mobility_uk.set_index('Date')
mobility_uk_first_two_weeks = mobility_uk_first_two_weeks.loc['2020-03-23':'2020-04-05',:]
mobility_uk_first_two_weeks_grouped = mobility_uk_first_two_weeks.groupby(['country_region']).mean()
mobility_uk_first_two_weeks_grouped.reset_index(inplace=True)
```

>Find the average for each category over the first two weeks from August 24th.


```python
mobility_uk_last_two_weeks = mobility_uk.set_index('Date')
mobility_uk_last_two_weeks = mobility_uk_last_two_weeks.loc['2020-08-24':'2020-09-06',:]
mobility_uk_last_two_weeks_grouped = mobility_uk_last_two_weeks.groupby(['country_region']).mean()
mobility_uk_last_two_weeks_grouped.reset_index(inplace=True)
```

>Define a function to display the averages for given the category.


```python
def avg_first_last_two_weeks(category):
    print("For the ",category, "category, the average change over first two weeks (wc/ 23 March) was", round(mobility_uk_first_two_weeks_grouped[category][0],1),"% and the average change over the last two weeks (wc/ 24 August) was", round(mobility_uk_last_two_weeks_grouped[category][0],1),"%.")
```

>Export dataframe to excel file for visualisation.


```python
mobility_uk.to_excel('data/mobility-data-uk.xlsx')
```

##### Create a new datafram with 5 regions containing major cities: Manchester, London, Birminham, Newcastle, Edinburgh and Glasgow.


```python
cities = ['Greater Manchester','Greater London','West Midlands','Tyne and Wear','Edinburgh','Glasgow City']
```

>Create a new dataframe with just these regions.


```python
mobility_regions = mobility.loc[mobility['sub_region_1'].isin(cities),:]
mobility_regions = mobility_regions.copy()
```

>Some of these regions are split into smaller sub-regions in the dataset. We will take the average of these sub-regions to represent the whole region.

>Find the average for each sub-region on each day.


```python
mobility_regions_grouped=mobility_regions.groupby(['sub_region_1',mobility_regions['Date']]).mean()
mobility_regions_grouped.reset_index(inplace=True)
```


```python
mobility_regions_grouped.to_excel('data/mobility_regions_grouped.xlsx')
```

>We also want to compare regions by taking an average of each month, to then look at April and August. To do this we group by month.


```python
#Add new column of the months.
mobility_regions['Month'] = pd.DatetimeIndex(mobility_regions.loc[:,'Date']).month
```


```python
#Group by sub-region and month.
mobility_regions_month_grouped=mobility_regions.groupby(['sub_region_1',mobility_regions['Month']]).mean()
```


```python
#Drop irrelevant columns.
mobility_regions_month_grouped.drop(['metro_area','census_fips_code'],axis=1,inplace=True)
```


```python
#Reset the index
mobility_regions_month_grouped.reset_index(inplace=True)
```

>Export dataframe to excel file for visualisation.


```python
mobility_regions_month_grouped.to_excel('data/mobility_regions_month_grouped.xlsx')
```

#### __Results: Mobility patterns during the COVID-19 pandemic__

>__Key findings__:
>1. Overall movement to different places dropped significantly at the start of lockdown.
>2. People are still travelling less in August / September, albeit closer to base levels.
>3. The number of people travelling to workplaces is more than 40% below the base level on weekdays.
>4. There are regional differences in mobility patterns, but the overall trends over time are the same.

#### UK Mobility Trends

>The number of visits to __workplaces__ began to fall in the middle in March after the UK the government announced all unecessary travel should be stopped (March 15th). When most workplaces closed on March 23rd, the number of visits to workplaces reached over 60% below base level. Since then the levels have increased to between 40% and 50% below a base weekday, and under 10% below a base weekend.

>Visits to __transit stations__ also dropped significantly at the start of lockdown to 70% below base levels and still remain at more than 30% below pre-lockdown levels.


```python
avg_first_last_two_weeks('Workplaces')
avg_first_last_two_weeks('Transit Stations')
```

    For the  Workplaces category, the average change over first two weeks (wc/ 23 March) was -62.1 % and the average change over the last two weeks (wc/ 24 August) was -36.0 %.
    For the  Transit Stations category, the average change over first two weeks (wc/ 23 March) was -70.0 % and the average change over the last two weeks (wc/ 24 August) was -34.6 %.


![image.png](attachment:7105a3ed-ebff-4a83-8165-f45b9afbc2bf.png)

>Visits to __groceries and pharmacies__ had a small increase in the week leading up to lockdown but then dropped to around 30% below usual levels, and remain about 9% below.

>Duration spent in __residential__ spaces increased by 23% in the first two weeks of lockdown and is now 9% above usual levels.


```python
avg_first_last_two_weeks('Grocery and Pharmacy')
avg_first_last_two_weeks('Residential')
```

    For the  Grocery and Pharmacy category, the average change over first two weeks (wc/ 23 March) was -30.9 % and the average change over the last two weeks (wc/ 24 August) was -8.6 %.
    For the  Residential category, the average change over first two weeks (wc/ 23 March) was 23.6 % and the average change over the last two weeks (wc/ 24 August) was 8.6 %.


![image.png](attachment:42397200-979b-4e25-9298-c6f2738ffc40.png)

>Time spent in __shops and other recreational facilities__ had the largest decline in the first two weeks of lockdown, at a 75% decrease from base levels. The majority of places in this category would have been closed. Since shops have re-opened, levels have increased slowly, but were still around 13% below usual levels in the past two weeks.

>Visits to __parks__ also dropped slightly at the start of lockdown but increased above usual levels during May. This data can fluctuate with the weather since it is a comparison with a base level set in February and March.


```python
avg_first_last_two_weeks('Retail and Recreation')
avg_first_last_two_weeks('Parks')
```

    For the  Retail and Recreation category, the average change over first two weeks (wc/ 23 March) was -74.6 % and the average change over the last two weeks (wc/ 24 August) was -12.5 %.
    For the  Parks category, the average change over first two weeks (wc/ 23 March) was -26.2 % and the average change over the last two weeks (wc/ 24 August) was 92.9 %.


![image.png](attachment:8e6fccd0-897e-462b-aeae-497d7c71210e.png)

#### Mobility Trends in Different Regions

>The graph below shows the change in the number of visits to workplaces for different regions in the UK, by week.
>The West Midlands had the smallest change whilst Edinburgh had the largest. This may be due to the split of region as we cannot assume they have the same rural / urban makeup. There are oscillations between weekdays and weekends so we take the average per week to look at the trends over time.

![image.png](attachment:61a3721a-0476-4c2b-89fa-2cf376d7e3a2.png)

>Comparing the average over April and August, Edinburgh and Greater London have the greatest % decrease in visits to workplaces.

>If we compare with the change in Nitrogen Dioxide reductions from April 2019 to April 2020 (see part 1.a), there are similarities but a strong regional correlation cannot be confirmed at this point. London had one of the highest reductions in Nitrogen Dioxide and also one of highest reductions in visits to workplaces.

![image.png](attachment:5c64e7fd-a8ea-4069-b5ee-12adb9f2458b.png)

#### __Further research__

This report only examines people's travel habits so does not take into account other factors that contribute to air pollution. Future research may compare air quality with other changes such as industrial activity which was also halted during lockdown.

Another consideration of change of habits is people travelling to schools as they re-open in September. If a shift towards using cars, bicycles or walking occurs then this could impact overall transportation habits and, as a consequence, air quality.

---

#### __Conclusion: Transportation habits and the UK's Sustainability targets__

It is clear that the overall amount of travel in the UK has decreased in line with the increase in strincency levels. This is likely linked to a change in working habits, with a focus on working from home where possible. The closing of non-essential businesses and restrictions on social gatherings also reduced the need to travel, as reflected in people spending more time at home and making fewer trips to shops.

The reduction in car usage leads to less traffic, which ultimately leads to the reduction of NOx emissions in major cities. Although it is too soon to know the permanence of working from home, we can say that this shift has led to decreased NOx levels in major cities. If working patterns change permanently, or have more flexibility, this would help the UK meet its 25-year air quality targets.

However, it also must be considered that as the UK slowly lowers stringency levels, people are averse to using public transport, opting to use private transportation to reduce the likelihood of COVID-19 infection. This is shown by the level of car usage moving towards base levels in August and September, despite the lower level of overall movement of people.

The transportation data and the Google mobility data indicate a shift towards cycling and visiting parks during the lockdown period, which helps towards the UK's sustainability goal of engagement with the natural environment to aid general wellbeing. Visits to parks seem to remain high, but may be impacted by the upcoming winter and poorer weather. It is likely we will not know whether this is a permanent habit change until summer 2021.

---

## 2) Aggregate habits: The overall impact of the COVID-19 pandemic and sustainability on businesses, investors and consumers.

### 2. a) Economic impact of COVID-19 on companies by sector

#### __Introduction__

It's clear that the COVID-19 pandemic affected different sectors of the economy heterogeneously. Thus to begin to explore in what ways habits changed, and which sectors saw greater demand we began with a sector-level analysis of the UK economy. This involved merging stock price data provided with information on the sector of each company in the FTSE 100. 

#### __References__:

Yahoo Finance (2020), URL: https://finance.yahoo.com/ (Accessed on 12 August 2020)

#### __Preparing and exploring the Data__


```python
import pip
import pandas as pd
import matplotlib.pyplot as plt
import pandas_datareader as pdr
import datetime 
from pandas_datareader import data
```

    /usr/local/lib/python3.6/dist-packages/pandas_datareader/compat/__init__.py:7: FutureWarning: pandas.util.testing is deprecated. Use the functions in the public API at pandas.testing instead.
      from pandas.util.testing import assert_frame_equal



```python
# Merge Yahoo finance stocks data with list of sectors for each company
csv3_df = pd.read_csv('hackathon_stocks3.csv')
csv3_df.head()
ts2_df = pd.read_csv('tickersector2.csv')
ts2_df.head()
result2 = pd.merge(csv3_df,ts2_df,on='ticker',how='inner')
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>18/06/2020</th>
      <th>19/06/2020</th>
      <th>22/06/2020</th>
      <th>23/06/2020</th>
      <th>24/06/2020</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>816.599976</td>
      <td>844.200012</td>
      <td>826.400024</td>
      <td>834.400024</td>
      <td>788.000000</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2312.000000</td>
      <td>2319.000000</td>
      <td>2329.000000</td>
      <td>2331.000000</td>
      <td>2305.000000</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1770.938843</td>
      <td>1804.646606</td>
      <td>1807.406372</td>
      <td>1858.460693</td>
      <td>1801.689697</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>889.799988</td>
      <td>892.200012</td>
      <td>902.200012</td>
      <td>920.000000</td>
      <td>905.200012</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2633.046875</td>
      <td>2703.195557</td>
      <td>2744.691895</td>
      <td>2768.404053</td>
      <td>2647.866943</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>226.399994</td>
      <td>227.399994</td>
      <td>233.100006</td>
      <td>230.699997</td>
      <td>227.300003</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4471.257324</td>
      <td>4595.265625</td>
      <td>4503.995605</td>
      <td>4505.979492</td>
      <td>4444.471191</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>127.019997</td>
      <td>127.760002</td>
      <td>126.779999</td>
      <td>129.139999</td>
      <td>125.040001</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2433.000000</td>
      <td>2365.000000</td>
      <td>2354.000000</td>
      <td>2372.000000</td>
      <td>2204.000000</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>640.799988</td>
      <td>660.200012</td>
      <td>639.000000</td>
      <td>647.000000</td>
      <td>625.599976</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1264 columns</p>
</div>




```python
#Check merge by looking at how stock prices vary by industry at a specific by date
result2.groupby('industryclassification')['17/08/2015'].mean().plot(kind='bar').set_title('FTSE 100 Stock price by industry 17/08/2015 ')
plt.ylabel('Change in stock price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_144_0.png)



```python
#Find locations of columns for key dates to caluculate change over the pandemic
result2.columns.get_loc("01/04/2019")
```




    918




```python
result2.columns.get_loc("28/06/2019")
```




    978




```python
# Find the mean stock price in Q2 2019
result2['meanq22019'] = result2.iloc[:, [918,978]].mean(axis=1)
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>22/06/2020</th>
      <th>23/06/2020</th>
      <th>24/06/2020</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
      <th>meanq22019</th>
      <th>meanq22020</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>826.400024</td>
      <td>834.400024</td>
      <td>788.000000</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
      <td>1007.425964</td>
      <td>765.944366</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2329.000000</td>
      <td>2331.000000</td>
      <td>2305.000000</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
      <td>2109.170410</td>
      <td>2247.779419</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1807.406372</td>
      <td>1858.460693</td>
      <td>1801.689697</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
      <td>2028.645996</td>
      <td>1569.283630</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>902.200012</td>
      <td>920.000000</td>
      <td>905.200012</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
      <td>928.988861</td>
      <td>837.301666</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2744.691895</td>
      <td>2768.404053</td>
      <td>2647.866943</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
      <td>2019.509155</td>
      <td>2158.307983</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>233.100006</td>
      <td>230.699997</td>
      <td>227.300003</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
      <td>218.987335</td>
      <td>222.652519</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4503.995605</td>
      <td>4505.979492</td>
      <td>4444.471191</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
      <td>4429.922608</td>
      <td>4124.403198</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>126.779999</td>
      <td>129.139999</td>
      <td>125.040001</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
      <td>125.360275</td>
      <td>117.420223</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2354.000000</td>
      <td>2372.000000</td>
      <td>2204.000000</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
      <td>4110.555054</td>
      <td>2283.275024</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>639.000000</td>
      <td>647.000000</td>
      <td>625.599976</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
      <td>827.096741</td>
      <td>548.440460</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1266 columns</p>
</div>




```python
result2.columns.get_loc("01/04/2020")
```




    1172




```python
result2.columns.get_loc("30/06/2020")
```




    1232




```python
# Find the mean stock price for Q2 2020
result2['meanq22020'] = result2.iloc[:, [1172,1232]].mean(axis=1)
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>22/06/2020</th>
      <th>23/06/2020</th>
      <th>24/06/2020</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
      <th>meanq22019</th>
      <th>meanq22020</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>826.400024</td>
      <td>834.400024</td>
      <td>788.000000</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
      <td>1007.425964</td>
      <td>765.944366</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2329.000000</td>
      <td>2331.000000</td>
      <td>2305.000000</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
      <td>2109.170410</td>
      <td>2247.779419</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1807.406372</td>
      <td>1858.460693</td>
      <td>1801.689697</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
      <td>2028.645996</td>
      <td>1569.283630</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>902.200012</td>
      <td>920.000000</td>
      <td>905.200012</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
      <td>928.988861</td>
      <td>837.301666</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2744.691895</td>
      <td>2768.404053</td>
      <td>2647.866943</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
      <td>2019.509155</td>
      <td>2158.307983</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>233.100006</td>
      <td>230.699997</td>
      <td>227.300003</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
      <td>218.987335</td>
      <td>222.652519</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4503.995605</td>
      <td>4505.979492</td>
      <td>4444.471191</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
      <td>4429.922608</td>
      <td>4124.403198</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>126.779999</td>
      <td>129.139999</td>
      <td>125.040001</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
      <td>125.360275</td>
      <td>117.420223</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2354.000000</td>
      <td>2372.000000</td>
      <td>2204.000000</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
      <td>4110.555054</td>
      <td>2283.275024</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>639.000000</td>
      <td>647.000000</td>
      <td>625.599976</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
      <td>827.096741</td>
      <td>548.440460</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1266 columns</p>
</div>




```python
# Calculate the chane in mean stock price over 1 year
result2['changemeanq2'] = result2['meanq22020']-result2['meanq22019']
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>23/06/2020</th>
      <th>24/06/2020</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
      <th>meanq22019</th>
      <th>meanq22020</th>
      <th>changemeanq2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>834.400024</td>
      <td>788.000000</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
      <td>1007.425964</td>
      <td>765.944366</td>
      <td>-241.481598</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2331.000000</td>
      <td>2305.000000</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
      <td>2109.170410</td>
      <td>2247.779419</td>
      <td>138.609009</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1858.460693</td>
      <td>1801.689697</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
      <td>2028.645996</td>
      <td>1569.283630</td>
      <td>-459.362366</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>920.000000</td>
      <td>905.200012</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
      <td>928.988861</td>
      <td>837.301666</td>
      <td>-91.687195</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2768.404053</td>
      <td>2647.866943</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
      <td>2019.509155</td>
      <td>2158.307983</td>
      <td>138.798828</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>230.699997</td>
      <td>227.300003</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
      <td>218.987335</td>
      <td>222.652519</td>
      <td>3.665184</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4505.979492</td>
      <td>4444.471191</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
      <td>4429.922608</td>
      <td>4124.403198</td>
      <td>-305.519410</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>129.139999</td>
      <td>125.040001</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
      <td>125.360275</td>
      <td>117.420223</td>
      <td>-7.940052</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2372.000000</td>
      <td>2204.000000</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
      <td>4110.555054</td>
      <td>2283.275024</td>
      <td>-1827.280029</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>647.000000</td>
      <td>625.599976</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
      <td>827.096741</td>
      <td>548.440460</td>
      <td>-278.656281</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1267 columns</p>
</div>




```python
# Plot the absolute mean change in stock price for each industry beetween Q2 2019 and Q2 2020
result2.groupby('industryclassification')['changemeanq2'].mean().plot(kind='bar').set_title('FTSE 100 Mean Change in Stock Price by Industry between Q2 2019 and Q2 2020 ')
plt.ylabel('Change in stock price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_152_0.png)



```python
# Calculate the percentage change in mean stock price over one year
result2['percentchangeq2'] = (result2['meanq22020']-result2['meanq22019'])*100/ (result2['meanq22019'])
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>24/06/2020</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
      <th>meanq22019</th>
      <th>meanq22020</th>
      <th>changemeanq2</th>
      <th>percentchangeq2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>788.000000</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
      <td>1007.425964</td>
      <td>765.944366</td>
      <td>-241.481598</td>
      <td>-23.970158</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2305.000000</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
      <td>2109.170410</td>
      <td>2247.779419</td>
      <td>138.609009</td>
      <td>6.571731</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1801.689697</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
      <td>2028.645996</td>
      <td>1569.283630</td>
      <td>-459.362366</td>
      <td>-22.643791</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>905.200012</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
      <td>928.988861</td>
      <td>837.301666</td>
      <td>-91.687195</td>
      <td>-9.869569</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2647.866943</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
      <td>2019.509155</td>
      <td>2158.307983</td>
      <td>138.798828</td>
      <td>6.872899</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>227.300003</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
      <td>218.987335</td>
      <td>222.652519</td>
      <td>3.665184</td>
      <td>1.673697</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4444.471191</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
      <td>4429.922608</td>
      <td>4124.403198</td>
      <td>-305.519410</td>
      <td>-6.896721</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>125.040001</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
      <td>125.360275</td>
      <td>117.420223</td>
      <td>-7.940052</td>
      <td>-6.333786</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2204.000000</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
      <td>4110.555054</td>
      <td>2283.275024</td>
      <td>-1827.280029</td>
      <td>-44.453365</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>625.599976</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
      <td>827.096741</td>
      <td>548.440460</td>
      <td>-278.656281</td>
      <td>-33.690893</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1268 columns</p>
</div>




```python
result2.groupby('industryclassification')['percentchangeq2'].mean().plot(kind='bar').set_title('FTSE 100 Mean Percentage Change in Stock Price by Industry between Q2 2019 and Q2 2020')
plt.ylabel('Percentage change in stock price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_154_0.png)



```python
# Create the percentage change in mean stock price by industry
industrypercentchange = result2.groupby('industryclassification')['percentchangeq2'].mean()
type(industrypercentchange)
```




    pandas.core.series.Series




```python
# Find the industries with the largest percentage incease in stock price
largest= industrypercentchange.nlargest(n=5, keep='first')
largest 
```




    industryclassification
    Precious Metals and Mining        66.622579
    Water                             55.115205
    Equity Investment Instruments     32.031755
    Software and Computer Services    28.340028
    Gas, Water & Multi-utilities      22.678958
    Name: percentchangeq2, dtype: float64




```python
# Find the industries with the largest percentage decease in stock price
smallest = industrypercentchange.nsmallest(n=5, keep='first')
smallest.sort_values(ascending=False)
```




    industryclassification
    Fixed Line Telecommunications   -40.719483
    Oil & Gas Producers             -42.239573
    Retail hospitality              -44.453365
    Automobiles & Parts             -45.908630
    Industrial Metals & Mining      -53.991951
    Name: percentchangeq2, dtype: float64




```python
# Sort above data into ascending oreder, plotting obly the industries with the 5  increases and decreases
highestlowest2= smallest.append(largest.sort_values(ascending=True))
highestlowest2.plot(kind='bar').set_title('FTSE 100 Mean Percentage Change in Stock Price by Industry for sectors with 5 largest increase and decrease')
plt.ylabel('Percetage hange in stock price')
plt.xlabel('Industry Classification')
plt.show()
highestlowest2
```


![png](output_158_0.png)





    industryclassification
    Industrial Metals & Mining       -53.991951
    Automobiles & Parts              -45.908630
    Retail hospitality               -44.453365
    Oil & Gas Producers              -42.239573
    Fixed Line Telecommunications    -40.719483
    Gas, Water & Multi-utilities      22.678958
    Software and Computer Services    28.340028
    Equity Investment Instruments     32.031755
    Water                             55.115205
    Precious Metals and Mining        66.622579
    Name: percentchangeq2, dtype: float64




```python
smallest.plot(kind='bar').set_title('FTSE 100 Mean Percentage Change in Stock Price by Industry between Q2 2019 and Q2 2020 for sectors with 5 largest decrease')
plt.ylabel('Percetage hange in stock price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_159_0.png)



```python
# Plot horizontally for ease of reading
highestlowest2.plot(kind='barh').set_title('FTSE 100 Mean Percentage Change in Stock Price by Industry for sectors with 5 largest increase and decrease')
plt.ylabel('Industry Classification')
plt.xlabel('Percetage change in stock price')
plt.show()
```


![png](output_160_0.png)



```python
# Find the columns containng start and end date for change analysis
result2.columns.get_loc("02/01/2020")
```




    1108




```python
result2.columns.get_loc("03/08/2020")
```




    1256




```python
# Calculate the change in stock price between two specific dates during which ther pandemic affected demand and supply
result2['difference2020'] = result2["03/08/2020"] - result2["02/01/2020"]
result2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ticker</th>
      <th>13/08/2015</th>
      <th>14/08/2015</th>
      <th>17/08/2015</th>
      <th>18/08/2015</th>
      <th>19/08/2015</th>
      <th>20/08/2015</th>
      <th>21/08/2015</th>
      <th>24/08/2015</th>
      <th>25/08/2015</th>
      <th>26/08/2015</th>
      <th>27/08/2015</th>
      <th>28/08/2015</th>
      <th>01/09/2015</th>
      <th>02/09/2015</th>
      <th>03/09/2015</th>
      <th>04/09/2015</th>
      <th>07/09/2015</th>
      <th>08/09/2015</th>
      <th>09/09/2015</th>
      <th>10/09/2015</th>
      <th>11/09/2015</th>
      <th>14/09/2015</th>
      <th>15/09/2015</th>
      <th>16/09/2015</th>
      <th>17/09/2015</th>
      <th>18/09/2015</th>
      <th>21/09/2015</th>
      <th>22/09/2015</th>
      <th>23/09/2015</th>
      <th>24/09/2015</th>
      <th>25/09/2015</th>
      <th>28/09/2015</th>
      <th>29/09/2015</th>
      <th>30/09/2015</th>
      <th>01/10/2015</th>
      <th>02/10/2015</th>
      <th>05/10/2015</th>
      <th>06/10/2015</th>
      <th>07/10/2015</th>
      <th>...</th>
      <th>25/06/2020</th>
      <th>26/06/2020</th>
      <th>29/06/2020</th>
      <th>30/06/2020</th>
      <th>01/07/2020</th>
      <th>02/07/2020</th>
      <th>03/07/2020</th>
      <th>06/07/2020</th>
      <th>07/07/2020</th>
      <th>08/07/2020</th>
      <th>09/07/2020</th>
      <th>10/07/2020</th>
      <th>13/07/2020</th>
      <th>14/07/2020</th>
      <th>15/07/2020</th>
      <th>16/07/2020</th>
      <th>17/07/2020</th>
      <th>20/07/2020</th>
      <th>21/07/2020</th>
      <th>22/07/2020</th>
      <th>23/07/2020</th>
      <th>24/07/2020</th>
      <th>27/07/2020</th>
      <th>28/07/2020</th>
      <th>29/07/2020</th>
      <th>30/07/2020</th>
      <th>31/07/2020</th>
      <th>03/08/2020</th>
      <th>04/08/2020</th>
      <th>05/08/2020</th>
      <th>06/08/2020</th>
      <th>07/08/2020</th>
      <th>10/08/2020</th>
      <th>11/08/2020</th>
      <th>industryclassification</th>
      <th>meanq22019</th>
      <th>meanq22020</th>
      <th>changemeanq2</th>
      <th>percentchangeq2</th>
      <th>difference2020</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>III</td>
      <td>465.132538</td>
      <td>467.772888</td>
      <td>464.252441</td>
      <td>463.372375</td>
      <td>449.290772</td>
      <td>441.809937</td>
      <td>428.784485</td>
      <td>414.438873</td>
      <td>432.480835</td>
      <td>421.919708</td>
      <td>436.529297</td>
      <td>432.832886</td>
      <td>404.141663</td>
      <td>416.023010</td>
      <td>424.735962</td>
      <td>415.670990</td>
      <td>416.551086</td>
      <td>423.503845</td>
      <td>427.552307</td>
      <td>421.567627</td>
      <td>417.871185</td>
      <td>413.206696</td>
      <td>419.279388</td>
      <td>421.303619</td>
      <td>417.519196</td>
      <td>410.830444</td>
      <td>414.790833</td>
      <td>406.869995</td>
      <td>417.079132</td>
      <td>412.766693</td>
      <td>424.647980</td>
      <td>414.702881</td>
      <td>402.205444</td>
      <td>410.390350</td>
      <td>411.358460</td>
      <td>415.142944</td>
      <td>428.432373</td>
      <td>433.536957</td>
      <td>430.104645</td>
      <td>...</td>
      <td>816.799988</td>
      <td>823.400024</td>
      <td>845.599976</td>
      <td>832.599976</td>
      <td>831.200012</td>
      <td>846.400024</td>
      <td>833.400024</td>
      <td>863.400024</td>
      <td>841.400024</td>
      <td>821.400024</td>
      <td>815.799988</td>
      <td>825.200012</td>
      <td>844.200012</td>
      <td>831.200012</td>
      <td>874.000000</td>
      <td>867.000000</td>
      <td>862.799988</td>
      <td>865.0</td>
      <td>870.000000</td>
      <td>871.000000</td>
      <td>867.000000</td>
      <td>870.000000</td>
      <td>870.000000</td>
      <td>869.799988</td>
      <td>884.200012</td>
      <td>868.400024</td>
      <td>889.599976</td>
      <td>911.599976</td>
      <td>903.400024</td>
      <td>925.799988</td>
      <td>918.200012</td>
      <td>925.400024</td>
      <td>917.000000</td>
      <td>934.599976</td>
      <td>Financial Services</td>
      <td>1007.425964</td>
      <td>765.944366</td>
      <td>-241.481598</td>
      <td>-23.970158</td>
      <td>-182.508667</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ADM</td>
      <td>1282.060059</td>
      <td>1267.971558</td>
      <td>1295.268066</td>
      <td>1290.865479</td>
      <td>1340.175659</td>
      <td>1397.410400</td>
      <td>1374.516479</td>
      <td>1325.206299</td>
      <td>1362.189087</td>
      <td>1326.086670</td>
      <td>1357.786133</td>
      <td>1364.830688</td>
      <td>1334.892334</td>
      <td>1356.025391</td>
      <td>1372.755371</td>
      <td>1363.949951</td>
      <td>1365.711182</td>
      <td>1394.768677</td>
      <td>1421.184814</td>
      <td>1377.446655</td>
      <td>1372.079956</td>
      <td>1368.501953</td>
      <td>1373.868652</td>
      <td>1376.552002</td>
      <td>1366.713135</td>
      <td>1358.662964</td>
      <td>1364.924072</td>
      <td>1319.307495</td>
      <td>1341.668701</td>
      <td>1321.990845</td>
      <td>1347.929688</td>
      <td>1319.307495</td>
      <td>1301.418457</td>
      <td>1343.457520</td>
      <td>1338.985474</td>
      <td>1335.407471</td>
      <td>1349.718628</td>
      <td>1358.662964</td>
      <td>1347.035400</td>
      <td>...</td>
      <td>2304.000000</td>
      <td>2313.000000</td>
      <td>2300.000000</td>
      <td>2299.000000</td>
      <td>2293.000000</td>
      <td>2321.000000</td>
      <td>2278.000000</td>
      <td>2285.000000</td>
      <td>2265.000000</td>
      <td>2259.000000</td>
      <td>2240.000000</td>
      <td>2286.000000</td>
      <td>2286.000000</td>
      <td>2333.000000</td>
      <td>2349.000000</td>
      <td>2376.000000</td>
      <td>2363.000000</td>
      <td>NaN</td>
      <td>2338.000000</td>
      <td>2374.000000</td>
      <td>2372.000000</td>
      <td>2346.000000</td>
      <td>2362.000000</td>
      <td>2369.000000</td>
      <td>2403.000000</td>
      <td>2395.000000</td>
      <td>2400.000000</td>
      <td>2459.000000</td>
      <td>2471.000000</td>
      <td>2492.000000</td>
      <td>2485.000000</td>
      <td>2520.000000</td>
      <td>2536.000000</td>
      <td>2525.000000</td>
      <td>Nonlife Insurance</td>
      <td>2109.170410</td>
      <td>2247.779419</td>
      <td>138.609009</td>
      <td>6.571731</td>
      <td>208.675781</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AAL</td>
      <td>649.455261</td>
      <td>642.577637</td>
      <td>641.219238</td>
      <td>629.926514</td>
      <td>602.331726</td>
      <td>628.737854</td>
      <td>622.200012</td>
      <td>560.557312</td>
      <td>580.510620</td>
      <td>564.038574</td>
      <td>616.680969</td>
      <td>629.162415</td>
      <td>581.104858</td>
      <td>580.595398</td>
      <td>615.577209</td>
      <td>567.604614</td>
      <td>575.416199</td>
      <td>597.661865</td>
      <td>630.775635</td>
      <td>608.784668</td>
      <td>609.973450</td>
      <td>608.699646</td>
      <td>624.237793</td>
      <td>636.209656</td>
      <td>624.407654</td>
      <td>611.331848</td>
      <td>590.020142</td>
      <td>550.283630</td>
      <td>558.774353</td>
      <td>530.330444</td>
      <td>521.924683</td>
      <td>469.282135</td>
      <td>461.130981</td>
      <td>467.753845</td>
      <td>471.234985</td>
      <td>470.046295</td>
      <td>492.037262</td>
      <td>513.009277</td>
      <td>564.208313</td>
      <td>...</td>
      <td>1815.291138</td>
      <td>1813.122803</td>
      <td>1838.157227</td>
      <td>1842.493896</td>
      <td>1798.535889</td>
      <td>1845.647827</td>
      <td>1808.588989</td>
      <td>1833.426270</td>
      <td>1815.291138</td>
      <td>1847.027710</td>
      <td>1857.475098</td>
      <td>1897.293701</td>
      <td>1939.871826</td>
      <td>1939.083374</td>
      <td>1925.284912</td>
      <td>1902.812988</td>
      <td>1931.001343</td>
      <td>NaN</td>
      <td>1921.145264</td>
      <td>1911.683472</td>
      <td>1934.352417</td>
      <td>1928.438843</td>
      <td>1956.233032</td>
      <td>1956.430054</td>
      <td>1945.391357</td>
      <td>1856.489502</td>
      <td>1843.282349</td>
      <td>1883.100830</td>
      <td>1853.138428</td>
      <td>1939.477661</td>
      <td>1901.827393</td>
      <td>1860.629150</td>
      <td>1876.201660</td>
      <td>1896.505127</td>
      <td>Mining</td>
      <td>2028.645996</td>
      <td>1569.283630</td>
      <td>-459.362366</td>
      <td>-22.643791</td>
      <td>-233.567383</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ANTO</td>
      <td>503.366699</td>
      <td>500.728882</td>
      <td>504.245911</td>
      <td>493.694977</td>
      <td>485.342194</td>
      <td>502.487366</td>
      <td>495.013824</td>
      <td>468.636597</td>
      <td>509.521271</td>
      <td>493.694977</td>
      <td>537.657227</td>
      <td>535.458984</td>
      <td>505.125122</td>
      <td>507.762756</td>
      <td>524.468506</td>
      <td>496.332703</td>
      <td>533.700562</td>
      <td>536.338196</td>
      <td>540.734436</td>
      <td>531.502441</td>
      <td>534.140137</td>
      <td>520.951477</td>
      <td>532.381592</td>
      <td>531.502441</td>
      <td>520.064392</td>
      <td>511.242218</td>
      <td>498.891296</td>
      <td>462.720612</td>
      <td>462.720612</td>
      <td>451.251801</td>
      <td>446.399628</td>
      <td>424.344391</td>
      <td>433.784027</td>
      <td>440.841766</td>
      <td>441.988586</td>
      <td>449.487427</td>
      <td>474.189423</td>
      <td>473.748261</td>
      <td>508.595642</td>
      <td>...</td>
      <td>919.599976</td>
      <td>914.799988</td>
      <td>929.799988</td>
      <td>937.599976</td>
      <td>923.400024</td>
      <td>941.799988</td>
      <td>925.200012</td>
      <td>960.000000</td>
      <td>976.000000</td>
      <td>970.400024</td>
      <td>989.200012</td>
      <td>987.000000</td>
      <td>1000.500000</td>
      <td>1007.500000</td>
      <td>1006.500000</td>
      <td>1012.000000</td>
      <td>1035.000000</td>
      <td>NaN</td>
      <td>1037.000000</td>
      <td>1033.500000</td>
      <td>1054.000000</td>
      <td>1029.000000</td>
      <td>1066.500000</td>
      <td>1049.500000</td>
      <td>1045.500000</td>
      <td>1028.000000</td>
      <td>1027.500000</td>
      <td>1067.000000</td>
      <td>1055.000000</td>
      <td>1103.500000</td>
      <td>1090.500000</td>
      <td>1077.000000</td>
      <td>1095.500000</td>
      <td>1112.500000</td>
      <td>Mining</td>
      <td>928.988861</td>
      <td>837.301666</td>
      <td>-91.687195</td>
      <td>-9.869569</td>
      <td>130.635132</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AHT</td>
      <td>873.043091</td>
      <td>873.961182</td>
      <td>873.961182</td>
      <td>872.124939</td>
      <td>836.781067</td>
      <td>837.699036</td>
      <td>818.879578</td>
      <td>810.617310</td>
      <td>846.879334</td>
      <td>828.059753</td>
      <td>860.649719</td>
      <td>867.993957</td>
      <td>841.830200</td>
      <td>907.010132</td>
      <td>929.960632</td>
      <td>897.370666</td>
      <td>900.583862</td>
      <td>894.616638</td>
      <td>909.305176</td>
      <td>934.550842</td>
      <td>926.288696</td>
      <td>911.600098</td>
      <td>917.108337</td>
      <td>929.960632</td>
      <td>920.780518</td>
      <td>900.583862</td>
      <td>885.436523</td>
      <td>866.157837</td>
      <td>876.715210</td>
      <td>853.764465</td>
      <td>871.666138</td>
      <td>854.223572</td>
      <td>833.567871</td>
      <td>853.764465</td>
      <td>847.338440</td>
      <td>853.764465</td>
      <td>887.272522</td>
      <td>900.124817</td>
      <td>905.632996</td>
      <td>...</td>
      <td>2656.759033</td>
      <td>2667.627197</td>
      <td>2687.387451</td>
      <td>2686.399414</td>
      <td>2700.231445</td>
      <td>2742.715820</td>
      <td>2704.183594</td>
      <td>2728.883789</td>
      <td>2727.895752</td>
      <td>2632.058838</td>
      <td>2550.053955</td>
      <td>2534.245850</td>
      <td>2574.754150</td>
      <td>2540.173828</td>
      <td>2616.250488</td>
      <td>2582.658203</td>
      <td>2621.190674</td>
      <td>NaN</td>
      <td>2618.226563</td>
      <td>2636.010742</td>
      <td>2606.370605</td>
      <td>2550.053955</td>
      <td>2545.113770</td>
      <td>2520.413574</td>
      <td>2496.701416</td>
      <td>2437.420898</td>
      <td>2405.804443</td>
      <td>2497.689453</td>
      <td>2462.121094</td>
      <td>2551.041992</td>
      <td>2555.981934</td>
      <td>2581.670166</td>
      <td>2592.538330</td>
      <td>2706.159424</td>
      <td>Support Services</td>
      <td>2019.509155</td>
      <td>2158.307983</td>
      <td>138.798828</td>
      <td>6.872899</td>
      <td>133.436523</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>TSCO</td>
      <td>186.829681</td>
      <td>187.430893</td>
      <td>187.014694</td>
      <td>183.685043</td>
      <td>180.124191</td>
      <td>179.153030</td>
      <td>174.066086</td>
      <td>167.499298</td>
      <td>172.031326</td>
      <td>172.216293</td>
      <td>177.071991</td>
      <td>176.979553</td>
      <td>171.476364</td>
      <td>170.967682</td>
      <td>175.314713</td>
      <td>171.985046</td>
      <td>171.985046</td>
      <td>174.806000</td>
      <td>176.840790</td>
      <td>171.615112</td>
      <td>167.730545</td>
      <td>165.048294</td>
      <td>163.707245</td>
      <td>165.742004</td>
      <td>163.013550</td>
      <td>161.533676</td>
      <td>163.244766</td>
      <td>155.568100</td>
      <td>155.891830</td>
      <td>152.747147</td>
      <td>154.874420</td>
      <td>153.718308</td>
      <td>158.435287</td>
      <td>169.441589</td>
      <td>164.863358</td>
      <td>166.343201</td>
      <td>172.539993</td>
      <td>177.719437</td>
      <td>182.205216</td>
      <td>...</td>
      <td>226.399994</td>
      <td>230.699997</td>
      <td>232.100006</td>
      <td>228.100006</td>
      <td>223.300003</td>
      <td>221.800003</td>
      <td>221.500000</td>
      <td>218.899994</td>
      <td>218.199997</td>
      <td>215.000000</td>
      <td>211.600006</td>
      <td>214.800003</td>
      <td>215.000000</td>
      <td>213.100006</td>
      <td>214.399994</td>
      <td>215.899994</td>
      <td>214.600006</td>
      <td>NaN</td>
      <td>216.800003</td>
      <td>214.500000</td>
      <td>216.000000</td>
      <td>220.699997</td>
      <td>220.000000</td>
      <td>218.000000</td>
      <td>221.600006</td>
      <td>218.000000</td>
      <td>217.100006</td>
      <td>219.199997</td>
      <td>222.399994</td>
      <td>221.699997</td>
      <td>222.600006</td>
      <td>223.699997</td>
      <td>225.399994</td>
      <td>224.699997</td>
      <td>Food &amp; Drug Retailers</td>
      <td>218.987335</td>
      <td>222.652519</td>
      <td>3.665184</td>
      <td>1.673697</td>
      <td>-29.506577</td>
    </tr>
    <tr>
      <th>85</th>
      <td>ULVR</td>
      <td>2406.857666</td>
      <td>2394.908447</td>
      <td>2389.787842</td>
      <td>2373.571045</td>
      <td>2328.335449</td>
      <td>2292.489014</td>
      <td>2237.865234</td>
      <td>2154.223389</td>
      <td>2206.286377</td>
      <td>2171.292725</td>
      <td>2230.183838</td>
      <td>2238.718750</td>
      <td>2187.509033</td>
      <td>2200.311523</td>
      <td>2237.865234</td>
      <td>2194.337402</td>
      <td>2210.554199</td>
      <td>2217.381104</td>
      <td>2241.279297</td>
      <td>2190.923096</td>
      <td>2181.534424</td>
      <td>2175.560059</td>
      <td>2201.164795</td>
      <td>2252.374023</td>
      <td>2249.814453</td>
      <td>2232.743896</td>
      <td>2242.986084</td>
      <td>2177.266113</td>
      <td>2202.871826</td>
      <td>2166.171875</td>
      <td>2261.763428</td>
      <td>2225.916504</td>
      <td>2221.648926</td>
      <td>2292.489014</td>
      <td>2289.074707</td>
      <td>2306.145020</td>
      <td>2371.010986</td>
      <td>2379.545898</td>
      <td>2348.820068</td>
      <td>...</td>
      <td>4428.598145</td>
      <td>4483.162109</td>
      <td>4407.764648</td>
      <td>4320.462402</td>
      <td>4303.597656</td>
      <td>4385.938965</td>
      <td>4283.755859</td>
      <td>4317.486328</td>
      <td>4228.200195</td>
      <td>4215.303223</td>
      <td>4181.572754</td>
      <td>4159.747559</td>
      <td>4249.033691</td>
      <td>4271.851074</td>
      <td>4313.518066</td>
      <td>4276.811523</td>
      <td>4341.295898</td>
      <td>NaN</td>
      <td>4316.494141</td>
      <td>4295.660645</td>
      <td>4633.956543</td>
      <td>4640.900879</td>
      <td>4662.726563</td>
      <td>4651.813965</td>
      <td>4720.266602</td>
      <td>4616.099121</td>
      <td>4536.733887</td>
      <td>4627.012207</td>
      <td>4629.988281</td>
      <td>4626.020020</td>
      <td>4577.000000</td>
      <td>4539.000000</td>
      <td>4520.000000</td>
      <td>4485.000000</td>
      <td>Personal Goods</td>
      <td>4429.922608</td>
      <td>4124.403198</td>
      <td>-305.519410</td>
      <td>-6.896721</td>
      <td>383.567383</td>
    </tr>
    <tr>
      <th>86</th>
      <td>VOD</td>
      <td>177.035095</td>
      <td>176.702423</td>
      <td>176.776337</td>
      <td>177.146011</td>
      <td>173.745056</td>
      <td>171.859726</td>
      <td>166.277725</td>
      <td>158.625549</td>
      <td>162.063461</td>
      <td>160.289062</td>
      <td>166.610428</td>
      <td>167.608520</td>
      <td>162.654938</td>
      <td>164.170593</td>
      <td>167.756378</td>
      <td>164.909943</td>
      <td>166.832199</td>
      <td>167.978180</td>
      <td>169.752609</td>
      <td>167.904266</td>
      <td>165.575333</td>
      <td>163.579132</td>
      <td>161.508957</td>
      <td>162.026504</td>
      <td>159.845444</td>
      <td>160.252091</td>
      <td>160.732651</td>
      <td>156.666305</td>
      <td>159.697586</td>
      <td>157.035950</td>
      <td>160.917480</td>
      <td>153.191406</td>
      <td>151.084259</td>
      <td>154.115570</td>
      <td>151.047287</td>
      <td>152.415070</td>
      <td>157.109878</td>
      <td>157.886200</td>
      <td>154.078583</td>
      <td>...</td>
      <td>127.059998</td>
      <td>125.239998</td>
      <td>127.800003</td>
      <td>128.860001</td>
      <td>127.839996</td>
      <td>129.479996</td>
      <td>129.639999</td>
      <td>130.240005</td>
      <td>127.019997</td>
      <td>125.279999</td>
      <td>122.639999</td>
      <td>123.419998</td>
      <td>124.720001</td>
      <td>126.900001</td>
      <td>127.500000</td>
      <td>127.459999</td>
      <td>129.800003</td>
      <td>NaN</td>
      <td>130.339996</td>
      <td>129.979996</td>
      <td>128.800003</td>
      <td>122.160004</td>
      <td>120.980003</td>
      <td>120.660004</td>
      <td>123.099999</td>
      <td>118.580002</td>
      <td>115.559998</td>
      <td>117.019997</td>
      <td>117.779999</td>
      <td>117.199997</td>
      <td>116.000000</td>
      <td>116.739998</td>
      <td>116.620003</td>
      <td>118.779999</td>
      <td>Mobile Telecommunications</td>
      <td>125.360275</td>
      <td>117.420223</td>
      <td>-7.940052</td>
      <td>-6.333786</td>
      <td>-25.898903</td>
    </tr>
    <tr>
      <th>87</th>
      <td>WTB</td>
      <td>4713.619141</td>
      <td>4718.164551</td>
      <td>4677.255859</td>
      <td>4649.982422</td>
      <td>4595.437500</td>
      <td>4527.255859</td>
      <td>4419.074707</td>
      <td>4296.348145</td>
      <td>4432.710449</td>
      <td>4381.802246</td>
      <td>4341.802246</td>
      <td>4360.893066</td>
      <td>4273.621094</td>
      <td>4279.984375</td>
      <td>4349.983887</td>
      <td>4262.711914</td>
      <td>4282.711426</td>
      <td>4214.529785</td>
      <td>4237.257324</td>
      <td>4236.348145</td>
      <td>4204.530273</td>
      <td>4207.257813</td>
      <td>4186.348633</td>
      <td>4228.166016</td>
      <td>4254.529785</td>
      <td>4234.529785</td>
      <td>4228.166016</td>
      <td>4140.894043</td>
      <td>4179.984863</td>
      <td>4226.348633</td>
      <td>4339.074707</td>
      <td>4246.348145</td>
      <td>4160.893555</td>
      <td>4243.620605</td>
      <td>4260.893066</td>
      <td>4254.529785</td>
      <td>4317.257324</td>
      <td>4335.438477</td>
      <td>4235.438965</td>
      <td>...</td>
      <td>2140.000000</td>
      <td>2195.000000</td>
      <td>2230.000000</td>
      <td>2222.000000</td>
      <td>2253.000000</td>
      <td>2349.000000</td>
      <td>2387.000000</td>
      <td>2440.000000</td>
      <td>2305.000000</td>
      <td>2262.000000</td>
      <td>2164.000000</td>
      <td>2268.000000</td>
      <td>2319.000000</td>
      <td>2246.000000</td>
      <td>2412.000000</td>
      <td>2344.000000</td>
      <td>2314.000000</td>
      <td>NaN</td>
      <td>2365.000000</td>
      <td>2267.000000</td>
      <td>2265.000000</td>
      <td>2290.000000</td>
      <td>2227.000000</td>
      <td>2255.000000</td>
      <td>2273.000000</td>
      <td>2286.000000</td>
      <td>2180.000000</td>
      <td>2220.000000</td>
      <td>2302.000000</td>
      <td>2392.000000</td>
      <td>2353.000000</td>
      <td>2379.000000</td>
      <td>2447.000000</td>
      <td>2573.000000</td>
      <td>Retail hospitality</td>
      <td>4110.555054</td>
      <td>2283.275024</td>
      <td>-1827.280029</td>
      <td>-44.453365</td>
      <td>-1986.270020</td>
    </tr>
    <tr>
      <th>88</th>
      <td>WPP</td>
      <td>1115.634766</td>
      <td>1107.046997</td>
      <td>1110.950562</td>
      <td>1112.512085</td>
      <td>1092.994263</td>
      <td>1085.967651</td>
      <td>1057.081543</td>
      <td>1018.046021</td>
      <td>1063.327148</td>
      <td>1023.510925</td>
      <td>1043.809326</td>
      <td>1054.739380</td>
      <td>1023.510925</td>
      <td>1027.414551</td>
      <td>1050.055054</td>
      <td>1033.660156</td>
      <td>1044.590088</td>
      <td>1057.862305</td>
      <td>1072.695679</td>
      <td>1068.011353</td>
      <td>1051.616455</td>
      <td>1043.028687</td>
      <td>1052.397217</td>
      <td>1064.107910</td>
      <td>1060.984863</td>
      <td>1057.862305</td>
      <td>1066.450195</td>
      <td>1038.344482</td>
      <td>1053.178223</td>
      <td>1037.563843</td>
      <td>1067.230835</td>
      <td>1043.028687</td>
      <td>1034.441040</td>
      <td>1071.915039</td>
      <td>1071.134277</td>
      <td>1073.476563</td>
      <td>1106.266235</td>
      <td>1106.266235</td>
      <td>1100.020508</td>
      <td>...</td>
      <td>616.200012</td>
      <td>612.799988</td>
      <td>626.799988</td>
      <td>630.799988</td>
      <td>621.599976</td>
      <td>630.599976</td>
      <td>623.200012</td>
      <td>632.000000</td>
      <td>624.799988</td>
      <td>591.400024</td>
      <td>575.599976</td>
      <td>585.599976</td>
      <td>593.400024</td>
      <td>603.799988</td>
      <td>610.400024</td>
      <td>624.200012</td>
      <td>608.200012</td>
      <td>NaN</td>
      <td>614.200012</td>
      <td>608.200012</td>
      <td>626.000000</td>
      <td>617.400024</td>
      <td>603.000000</td>
      <td>592.400024</td>
      <td>593.200012</td>
      <td>580.200012</td>
      <td>568.000000</td>
      <td>593.000000</td>
      <td>610.200012</td>
      <td>612.200012</td>
      <td>610.000000</td>
      <td>611.799988</td>
      <td>620.599976</td>
      <td>644.200012</td>
      <td>Media</td>
      <td>827.096741</td>
      <td>548.440460</td>
      <td>-278.656281</td>
      <td>-33.690893</td>
      <td>-416.542847</td>
    </tr>
  </tbody>
</table>
<p>89 rows × 1269 columns</p>
</div>




```python
# Look at the mean difference in stock price beetween the two dates, by industry and as a percentage change
result2['difference2020percent'] = (result2['difference2020']*100)/ (result2['02/01/2020'])
result2
result2.groupby('industryclassification')['difference2020percent'].mean().plot(kind='bar').set_title('FTSE 100 Mean Change in Stock Price by Industry between 02/01/2020 and 03/08/2020.')
plt.ylabel('Change in Stock Price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_164_0.png)



```python
# Find the industries with the largest percentage increase in stock price between the start and end date chosen
industrydifpercentchange = result2.groupby('industryclassification')['difference2020percent'].mean()
largestdif= industrydifpercentchange.nlargest(n=5, keep='first')
largestdif 
```




    industryclassification
    Precious Metals and Mining        68.063952
    Equity Investment Instruments     52.938257
    Industrial Engineering            16.686451
    Mining                            15.157240
    Software and Computer Services    14.930810
    Name: difference2020percent, dtype: float64




```python
# Find the industries with the largest percentage decrease in stock price between the start and end date chosen
smallestdif = industrydifpercentchange.nsmallest(n=5, keep='first')
smallestdif.sort_values(ascending=False)
```




    industryclassification
    Banks                           -45.012294
    Retail hospitality              -47.221648
    Oil & Gas Producers             -47.870737
    Fixed Line Telecommunications   -50.005102
    Automobiles & Parts             -61.931180
    Name: difference2020percent, dtype: float64




```python
# Sort the values in descending orderand plot the percentage changes in stock price between the start and end date
highestlowest2dif= largestdif.append(smallestdif.sort_values(ascending=False))
highestlowest2dif.plot(kind='bar').set_title('FTSE 100 Mean Change in Stock Price by Industry between 02/01/2020 and 03/08/2020.')
plt.ylabel('Change in Stock Price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_167_0.png)



```python
# Display horizontally for easy reading
highestlowest2dif.plot(kind='barh').set_title('FTSE 100 Mean Change in Stock Price by Industry between 02/01/2020 and 03/08/2020.')
plt.ylabel('Change in Stock Price')
plt.xlabel('Industry Classification')
plt.show()
```


![png](output_168_0.png)



```python
highestlowest2.plot(kind='barh').set_title('Percentage change in stock price by industry between Q2 2019 and Q2 2020 ')
plt.show()
```


![png](output_169_0.png)



```python
# Add axes labels and title to form key result 1: percentage changes by industry betwen Q2 2019 and Q2 2020
highestlowest2.plot(kind='barh').set_title('Percentage change in stock price by industry between Q2 2019 and Q2 2020 ')
plt.ylabel('Industry Classification')
plt.xlabel('Percentage change in stock price')
```




    Text(0.5, 0, 'Percentage change in stock price')




![png](output_170_1.png)



```python
# Key result 2: percentage changes by industry betwen 02/01/2020 and 03/08/2020
highestlowest2dif.plot(kind='barh').set_title('Percentage change in stock price by industry between 02/01/2020 andd 03/08/2020')
plt.ylabel('Industry Classification')
plt.xlabel('Percentage change in stock price')
# Reassuringly, this graph is broadly similar to the one above, lending confidence to the assertion that the relative indusrty analysis is robust to looking at the impact of the pandemic on a 1 year or 7 month horizon. 
```




    Text(0.5, 0, 'Percentage change in stock price')




![png](output_171_1.png)


#### __Conclusion:__

Figure 1 shows the change in the share price of FTSE100 firms between Q22019 and Q2 2020. The industries that experienced the largest falls in stock price include, automobiles, retail hospitality, oil and gas, and fixed line telecommunications.This result is robust to analysing the stock price change over a shorter timeframe too (specifically between 02/01/2020 and 03/08/2020). 

At the other end of the spectrum some industries have outperformed the market, including software and computer manuufacturers, precious metals and mining, and equity investment instruments. By contrast, FTSE 100 bank stocks performed poorly. 

Changes in stock prices may reflect: changes in final or intermediate demand, or restrictions in supply. In this way, the prices outlines above are largely unsurprising.

Whilst COVID was by far the biggest shock during the time frame studies, other factors may also have affected share prices over this period (industry fixed effects). Further limitations of this evidence are that stock price data does not include small firms or firms which are not publicly listed, or in the third/ public sector. Finally, FTSE 100 firms operate internationally,  so fluctuates in their share prices will represent the effects not only on the UK economy but also in other markets.

Overall, the sector level analysis hints at the following key results which we were then able to explore in more disaggregated approaches:
- the automobile industry suffered significantly due to COVID-19, perhaps because people reduced their use of cars, and delayed purchasing new car.
- software and computer science companies may have experienced increased demand for their service
- retail and hospitality sectors saw huge falls in demand during the crisis, as people reduced their number of holidays and restrictions prevented them from operning. 

---

After looking how different  sectors of the economy were affected, we decided to dive more deeply into the types of companies that did well during the pandemic, and whether this was influenced by their environmental, social and ethical sustainability policies.

---

### 2.b) The rise of ESG firms

#### __Introduction__

As people have grown more environmentally and socially conscious, there has been an increase in demand from the general public for firms to be more transparent in their ethical and environmental practices. The Environmental, Social and Governance (ESG) criteria allows this to occur by referring to three central factors that help measure the sustainability and societal impact of an investment in a company or business. This social criterion examines how the company manages its relationships with employees and supplies, governance relates to a company’s leadership, audits and shareholder rights; while more importantly the environmental criteria considers how a company performs in relation to the conservation of the natural world. 
Using this indicator, we can use the S&P Europe 350 ESG Index to measure the performance of ESG compliant firms as compared to the benchmark S&P Europe 350, from September 2019 to September 2020. 

#### __Description of data__
This dataset is taken directly from the Standard and Poor Dow Jones Indices website. It compares the stock price return on ESG firms compared to regular firms over the course of the year, which at the time of the data is September 2019 to September 2020.

Spglobal.com. (2020) S&P Europe 350 ESG Index - S&P Dow Jones Indices. [online] Available at: <https://www.spglobal.com/spdji/en/indices/equity/sp-europe-350-esg-index/#overview> [Accessed 16 September 2020]

#### __References:__

Lakhani, P., (2020) Why ESG Is Outperforming The S&P 500 - Openmarkets. [online] OpenMarkets. Available at: <https://openmarkets.cmegroup.com/16235/why-esg-is-outperforming-the-sp-500> [Accessed 16 September 2020].

European Commission (2020) Recovery Plan For Europe. [online] Available at: <https://ec.europa.eu/info/live-work-travel-eu/health/coronavirus-response/recovery-plan-europe_en> [Accessed 16 September 2020].

Nlfm.co.uk (2020)  April News Round Up | North Laine Financial Management | Brighton. [online] Available at: <https://www.nlfm.co.uk/blog-post/april-news-round-2> [Accessed 17 September 2020].

#### __Preparing and exploring the data__


```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.dates as mdates
# Importing the csv file which has the stock price return of S&P and S&P ESG firms, removing any unneccessary characters
performance=pd.read_csv("PerformanceComparisonGraph s&p EU.csv",sep=r'\s*,\s*',
                           header=0, encoding='ascii', engine='python')
# Turning the date into a date time format so python can recongise it as such
performance['Effective date']=pd.to_datetime(performance['Effective date'])

performance=performance.set_index('Effective date')
plt.figure(figsize=(30,20))
# Ploting the values of each stock price to the effective date
plt.plot(performance.index,performance.values)
plt.legend(['S&P Europe 350 Index','S&P Europe 350 ESG Index'], fontsize=16)
plt.xlabel("Date", fontsize=18)
plt.ylabel("Price return (EUR)", fontsize=18)
plt.title('S&P Europe 350 and S&P Europe 350 ESG Index 1 Year Price Return', fontsize=18)
plt.show()
```


![png](output_181_0.png)


#### __Key Findings__

As shown above, firms in the ESG index have slightly outperformed the bench mark S&P Europe 350 especially through this COVID period. 

Key reasons for this are that the commitment by ESG firms to improve their environmental standards mean that there is an active effort to reduce carbon footprint; investing in more sustainable and efficient energy resources such as solar power. Consequently, ESG funds typically have a low exposure to oil and gas, which gave them the edge when energy stocks suffered steep losses in April 2020 due to the oil crash.
Additionally, The European Commission's 750-billion-euro coronavirus recovery plan focuses on a 'green deal'. This will focus on promoting economic recovery while investing the commissions pledge to slash EU emissions to net zero by 2050 to tackle the threat of climate change.  

Although ESG firms’ better-quality governance was a contributing factor, their environmental initiatives which aligned with policies in the EU recovery plan and have allowed such firms to stabilise their stock prices, arguably had a larger impact on their performance. Hence allowing ESG firms to out-perform the benchmark while positively impacting the UK sustainability targets to mitigating climate change and use resources from nature more sustainably and efficiently.

---

### 2. b)  ESG Resiliance & The Impact of ESG Ratings on Tech Companies During the Pandemic 

#### __Introduction__ 

Consumer and investor habits have changed during the pandemic as shown by the previous sections. This had a knock-on effect on the stock market and some companies were more resilient than others. ESG has been growing in importance of the years and has been a megatrend for investors as seen by rising number of ESG reports by many sectors. Current research shows that ESG is no longer a fad but a longer trend in investing strategy.

The aim of this section is to understand how high and low ESG companies performed during the pandemic and if stock prices were determined by ESG ranking.  

#### __Description of the data__

The stock data table provided, and Yahoo Finance was used for this section. The top 5 and worst 5 ESG companies were selected based on their ranking in the responsibility index. Technology companies were selected to further analyse the impact ESG rankings have on tech stock price. The technology sector was one of the most resilient during the pandemic it would be interesting to find out if high ESG and low ESG tech companies experienced similar trends and if future trends look similar for both. Low and high ESG companies was determined through S&P 500 reports and Sustainalytics analysis. LSMT model code was used to predict stock price and was provided by user Fares Sayah from Kaggle. 


#### __References__:

Finance.yahoo.com. 2020. Yahoo Finance. [online] Available at: <https://finance.yahoo.com> [Accessed 17 September 2020].

Lakhani, P., 2020. Why ESG Is Outperforming The S&P 500 - Openmarkets. [online] OpenMarkets. Available at: <https://openmarkets.cmegroup.com/16235/why-esg-is-outperforming-the-sp-500> [Accessed 17 September 2020].

S&P 500 Dow Jones Indices, 2019. The S&P 500® ESG Index: Integrating Environmental, Social, And Governance Values Into The Core. [online] Available at: <https://www.spglobal.com/_media/documents/the-sp-500-esg-index-integrating-esg-values-into-the-core.pdf> [Accessed 17 September 2020].

Spglobal.com. 2020. S&P 500 ESG Index - S&P Dow Jones Indices. [online] Available at: <https://www.spglobal.com/spdji/en/indices/equity/sp-500-esg-index/#overview> [Accessed 17 September 2020].

Sustainalytics. 2020. Sustainalytics. [online] Available at: <https://www.sustainalytics.com> [Accessed 17 September 2020].

Tortoise. 2020. The Responsibility100 Index - Tortoise. [online] Available at: <https://www.tortoisemedia.com/intelligence/responsibility> [Accessed 17 September 2020].

Kaggle.com. 2020. Stock Market Analysis + Prediction Using LSTM. [online] Available at: <https://www.kaggle.com/faressayah/stock-market-analysis-prediction-using-lstm> [Accessed 17 September 2020].

#### __Preparing and exploring the data__


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy 
sns.set_style('whitegrid')
plt.style.use("fivethirtyeight")
%matplotlib inline
# For reading stock data from yahoo
from pandas_datareader.data import DataReader
# For time stamps
from datetime import datetime
import tensorflow as tf 
from tensorflow import keras 
#pip install sklearn
```

#### Quick FTSE Summary 


```python
s = pd.read_csv('/Users/maishachowdhury/Downloads/hackathon_stocks.csv')
```


```python
# Convert the date column to datetime64
s.Date = pd.to_datetime(s.Date)
```


```python
s.set_index('Date', inplace=True)
```


```python
best_worst = s[['ULVR', 'SMT']]
```


```python
# Plot data
best_worst.plot(subplots=True)
plt.title('Best & Worst FTSE ESG Company', y=2.20)
plt.xlabel('Date')
plt.ylabel('Stock Price', y=1.08)
plt.show()
```


![png](output_193_0.png)


Unilever (Retail and Consumer) has the highest ESG rating according to the responsibility index and Scottish Mortgage Trust (Finance) has the worst. Interestingly both companies did well during the pandemic. Research shows that the reseason SMT did very well even though it is a small invesment company with poor ESG rating is becuase they invested in tech companies that outperformed during the pandemic which helped boost their market price. 


```python
top_five = s[['ULVR', 'SVT', 'DGE', 'AZN', 'BT-A']]
```


```python
# Plot data
top_five.plot(subplots=True)
plt.title('Top 5 FTSE ESG Companies', y=6.20)
plt.xlabel('Date')
plt.ylabel('Stock Price', y=2.50)
plt.show()
```


![png](output_196_0.png)



```python
worst_five = s[['SMT', 'DCC', 'EVR', 'ICP', 'MRO']]
```


```python
# Plot data
worst_five.plot(subplots=True)
plt.title('Worst 5 FTSE ESG Companies', y=6.20)
plt.xlabel('Date')
plt.ylabel('Stock Price', y=2.50)
plt.show()
```


![png](output_198_0.png)

The two graphs above shows the top 5 ESG companies; Unilever (Retail and Consumer), Severn Trent (Engineering), Diageo (Retail and Consumer), AstraZeneca (Pharma) and BT group (Services). And the worst 5 ESG companies; Scottish Mortgage Investment Trust (Finance), DCC plc (Services), Evraz (Extraction), Intermediate Capital Holdings (Finance) and Melrose Industries (Finance) - According to the responsibility index. It is clear that high ESG companies were more resiliant during the pandemic whilst low ESG companies had steep declines during March 2020. It is noted that the top 5 and the worst 5 did not include any tech companies. Which we know did very well regardless of ESG ratings. As we come out of the pandemic the stock prices for top and worst companies have started to level off. Showing that more time and data is needed to determine if ESG investing and consumer support for ESG is a permenant trend. It is important to note that even though ESG companies were more resiliant e.g. less risk adverse it does not mean they offer higher returns than low ESG companies.  
#### Summary Statistics of 4 Tech Companies

Technology was one of the most resilient industries during the pandemic. It would be interesting to see if ESG rankings for tech companies make a difference to volatility and stock price. 

Technology companies were chosen to determine how much of an affect high ranking ESG companies achieved during the pandemic compared to low ranking ESG companies. 

Cisco and Intel are both high ranking ESG companies with low environmental risks.

Google and Amazon are both low ranking ESG companies with high environmental risks. In 2019 Google amongst others such as Facebook were dropped from the S&P 500 sustainability index. 

ESG ranking was determined through Sustainalytics and S&P reports. 


```python
# The tech stocks we'll use for this analysis


high_low_list = ['CSCO', 'INTC', 'GOOG', 'AMZN']

# Set up End and Start times for data grab
end = datetime.now()
start = datetime(end.year - 1, end.month, end.day)


#For loop for grabing yahoo finance data and setting as a dataframe
for stock in high_low_list:   
    # Set DataFrame as the Stock Ticker
    globals()[stock] = DataReader(stock, 'yahoo', start, end)
```


```python
company_list = [CSCO, INTC, GOOG, AMZN]
company_name = ['CSCO', 'INTC', 'GOOGLE', 'AMAZON']

for company, com_name in zip(company_list, company_name):
    company["company_name"] = com_name
    
df = pd.concat(company_list, axis=0)
df.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
      <th>company_name</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2020-09-03</th>
      <td>3488.409912</td>
      <td>3303.000000</td>
      <td>3485.000000</td>
      <td>3368.000000</td>
      <td>8161100.0</td>
      <td>3368.000000</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-04</th>
      <td>3381.500000</td>
      <td>3111.129883</td>
      <td>3318.000000</td>
      <td>3294.620117</td>
      <td>8781800.0</td>
      <td>3294.620117</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-08</th>
      <td>3250.850098</td>
      <td>3130.000000</td>
      <td>3144.000000</td>
      <td>3149.840088</td>
      <td>6094200.0</td>
      <td>3149.840088</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-09</th>
      <td>3303.179932</td>
      <td>3185.000000</td>
      <td>3202.989990</td>
      <td>3268.610107</td>
      <td>5188700.0</td>
      <td>3268.610107</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-10</th>
      <td>3349.889893</td>
      <td>3170.550049</td>
      <td>3307.219971</td>
      <td>3175.110107</td>
      <td>5330700.0</td>
      <td>3175.110107</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-11</th>
      <td>3217.340088</td>
      <td>3083.979980</td>
      <td>3208.689941</td>
      <td>3116.219971</td>
      <td>5094000.0</td>
      <td>3116.219971</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-14</th>
      <td>3187.389893</td>
      <td>3096.000000</td>
      <td>3172.939941</td>
      <td>3102.969971</td>
      <td>4529600.0</td>
      <td>3102.969971</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>3175.020020</td>
      <td>3108.919922</td>
      <td>3136.159912</td>
      <td>3156.129883</td>
      <td>4021500.0</td>
      <td>3156.129883</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-16</th>
      <td>3187.239990</td>
      <td>3074.149902</td>
      <td>3179.989990</td>
      <td>3078.100098</td>
      <td>4512200.0</td>
      <td>3078.100098</td>
      <td>AMAZON</td>
    </tr>
    <tr>
      <th>2020-09-17</th>
      <td>3029.429932</td>
      <td>2972.550049</td>
      <td>3009.250000</td>
      <td>3008.729980</td>
      <td>6432000.0</td>
      <td>3008.729980</td>
      <td>AMAZON</td>
    </tr>
  </tbody>
</table>
</div>




```python
CSCO.describe() # Summary Stats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>253.000000</td>
      <td>253.000000</td>
      <td>253.000000</td>
      <td>253.000000</td>
      <td>2.530000e+02</td>
      <td>253.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>45.333992</td>
      <td>44.275929</td>
      <td>44.829526</td>
      <td>44.822055</td>
      <td>2.418065e+07</td>
      <td>44.205677</td>
    </tr>
    <tr>
      <th>std</th>
      <td>3.164538</td>
      <td>3.583371</td>
      <td>3.428160</td>
      <td>3.369029</td>
      <td>1.317639e+07</td>
      <td>3.222971</td>
    </tr>
    <tr>
      <th>min</th>
      <td>35.820000</td>
      <td>32.400002</td>
      <td>33.230000</td>
      <td>33.200001</td>
      <td>7.044700e+06</td>
      <td>32.631130</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>42.660000</td>
      <td>41.810001</td>
      <td>42.139999</td>
      <td>42.250000</td>
      <td>1.644050e+07</td>
      <td>42.180000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>46.459999</td>
      <td>45.410000</td>
      <td>46.040001</td>
      <td>45.959999</td>
      <td>2.006990e+07</td>
      <td>45.262383</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>47.700001</td>
      <td>47.029999</td>
      <td>47.279999</td>
      <td>47.419998</td>
      <td>2.674720e+07</td>
      <td>46.660000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>50.279999</td>
      <td>49.400002</td>
      <td>49.750000</td>
      <td>49.930000</td>
      <td>1.069283e+08</td>
      <td>49.074467</td>
    </tr>
  </tbody>
</table>
</div>



#### Historical Closing Price of 2 High ESG Tech companies VS 2 Low ESG Tech Companies


```python
# Let's see a historical view of the closing price


plt.figure(figsize=(12, 8))
plt.subplots_adjust(top=1.25, bottom=1.2)

for i, company in enumerate(company_list, 1):
    plt.subplot(2, 2, i)
    company['Adj Close'].plot()
    plt.ylabel('Adj Close')
    plt.xlabel(None)
    plt.title(f"{high_low_list[i - 1]}")
```


![png](output_206_0.png)


The closing price dropped considerably for all 4 companies in March 2020. As expected, the tech companies’ closing price started to increase few weeks after and remained high throughout the months. Interestingly, Amazon bounced back quickly this is due to governments policy e.g. lockdown and closing of businesses. Amazon took charge of the demand and increased in revenue over the months. Amazon has had many scandals of poor working conditions and excess packaging as well as many more. Amazon ranks low on ESG metrics and this graph indicates that the high environmental and sustainability risks associated were not enough to push consumers or investors away. It is also noted that Cisco and Intel both high ESG tech companies had a sudden dip at the end of August this could be due to policy relaxation and software no longer being in demand for example when countries went into lock down workplaces made adjustments and bought technology and software during the months of March-July therefore extra purchases may not have been needed.

#### Total Volume of Stock Traded Each Day for CISCO, INTEL, GOOGLE and AMAZON 


```python
# Now let's plot the total volume of stock being traded each day
plt.figure(figsize=(12, 8))
plt.subplots_adjust(top=1.25, bottom=1.2)

for i, company in enumerate(company_list, 1):
    plt.subplot(2, 2, i)
    company['Volume'].plot()
    plt.ylabel('Volume of Stock')
    plt.xlabel(None)
    plt.title(f"{high_low_list[i - 1]}")
```


![png](output_209_0.png)


Both the high ESG companies Cisco and Intel had higher volume of stock traded during the latter part of 2020 whilst the companies with low ESG ratings Google and Amazon had more sporadic highs during the year. This could possibly show that investors and consumers are moving towards more ESG friendly companies. Many financial services companies have released reports that ESG investing is no longer a fad but a larger trend. However, this does not mean that ESG companies have higher returns. 

#### What was the moving average of the various stocks?


```python
ma_day = [10, 20, 50]

for ma in ma_day:
    for company in company_list:
        column_name = f"MA for {ma} days"
        company[column_name] = company['Adj Close'].rolling(ma).mean()
```


```python
print(CSCO.columns)
```

#### Moving Averages for CISCO, INTEL, GOOGLE and AMAZON 


```python
fig, axes = plt.subplots(nrows=2, ncols=2)
fig.set_figheight(8)
fig.set_figwidth(15)

CSCO[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[0,0])
axes[0,0].set_title('CISCO Moving Average')

INTC[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[0,1])
axes[0,1].set_title('INTEL Moving Average')

GOOG[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[1,0])
axes[1,0].set_title('GOOGLE Moving Average')

AMZN[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[1,1])
axes[1,1].set_title('AMAZON Moving Average')

fig.tight_layout()
```


![png](output_215_0.png)


The moving averages have consistently moved with the adjusted close price. Moving averages for these companies during the period of September 2019 to September 2020 show to be a reliable indicator for showing upward and downward trends. However, the lower ESG companies Google and Amazon had moving averages closer to the blue line which is the adjusted close price which shows more confidence and less volatility. This could be due to other factors and not just ESG. Both Google and Amazon are major players in their specific industries and cover a large market share. Their services were heavily used by majority of people as there is less of a choice for Google and Amazon services and prices tend to be competitive compared to smaller companies with high ESG ratings. 

#### Predicting the closing price stock price of CISCO 


```python
#Get the stock quote
df = DataReader('CSCO', data_source='yahoo', start='2012-01-01', end=datetime.now())
#Show the data
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>18.860001</td>
      <td>18.480000</td>
      <td>18.549999</td>
      <td>18.629999</td>
      <td>41236600.0</td>
      <td>14.382661</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>19.000000</td>
      <td>18.350000</td>
      <td>18.440001</td>
      <td>18.990000</td>
      <td>52927700.0</td>
      <td>14.660585</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>19.000000</td>
      <td>18.670000</td>
      <td>18.930000</td>
      <td>18.920000</td>
      <td>37865300.0</td>
      <td>14.606544</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>19.000000</td>
      <td>18.830000</td>
      <td>18.950001</td>
      <td>18.850000</td>
      <td>27796900.0</td>
      <td>14.552503</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>19.100000</td>
      <td>18.790001</td>
      <td>18.870001</td>
      <td>18.969999</td>
      <td>37811500.0</td>
      <td>14.645146</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-09-11</th>
      <td>40.049999</td>
      <td>39.520000</td>
      <td>39.770000</td>
      <td>39.880001</td>
      <td>21853000.0</td>
      <td>39.880001</td>
    </tr>
    <tr>
      <th>2020-09-14</th>
      <td>40.639999</td>
      <td>40.049999</td>
      <td>40.220001</td>
      <td>40.369999</td>
      <td>19866700.0</td>
      <td>40.369999</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>40.840000</td>
      <td>40.380001</td>
      <td>40.509998</td>
      <td>40.599998</td>
      <td>19024100.0</td>
      <td>40.599998</td>
    </tr>
    <tr>
      <th>2020-09-16</th>
      <td>41.169998</td>
      <td>40.389999</td>
      <td>40.720001</td>
      <td>40.419998</td>
      <td>24310200.0</td>
      <td>40.419998</td>
    </tr>
    <tr>
      <th>2020-09-17</th>
      <td>40.400002</td>
      <td>39.509998</td>
      <td>39.660000</td>
      <td>40.285000</td>
      <td>7231788.0</td>
      <td>40.285000</td>
    </tr>
  </tbody>
</table>
<p>2192 rows × 6 columns</p>
</div>




```python
plt.figure(figsize=(16,8))
plt.title('Close Price History CISCO')
plt.plot(df['Close'])
plt.xlabel('Date', fontsize=18)
plt.ylabel('Close Price USD ($)', fontsize=18)
plt.show()
```


![png](output_219_0.png)


Steady trend of close price history unlike FTSE companies with low ESG companies. However, the top and worst FTSE companies were not technology companies 

#### LSMT Model for CISCO


```python
#Create a new dataframe with only the 'Close column
data = df.filter(['Close'])
#Convert the dataframe to a numpy array
dataset = data.values
#Get the number of rows to train the model on
training_data_len = int(np.ceil( len(dataset) * .8 ))

training_data_len
```


```python
#Scale the data
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler(feature_range=(0,1))
scaled_data = scaler.fit_transform(dataset)

scaled_data
```


```python
#Create the training data set
#Create the scaled training data set
train_data = scaled_data[0:int(training_data_len), :]
#Split the data into x_train and y_train data sets
x_train = []
y_train = []

for i in range(60, len(train_data)):
    x_train.append(train_data[i-60:i, 0])
    y_train.append(train_data[i, 0])
    if i<= 61:
        print(x_train)
        print(y_train)
        print()
        
# Convert the x_train and y_train to numpy arrays 
x_train, y_train = np.array(x_train), np.array(y_train)

#Reshape the data
x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))
# x_train.shape
```


```python
from keras.models import Sequential
from keras.layers import Dense, LSTM

#Build the LSTM model
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape= (x_train.shape[1], 1)))
model.add(LSTM(50, return_sequences= False))
model.add(Dense(25))
model.add(Dense(1))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

#Train the model
model.fit(x_train, y_train, batch_size=1, epochs=1)
```

    Epoch 1/1
    1694/1694 [==============================] - 261s 154ms/step - loss: 0.0012





    <keras.callbacks.callbacks.History at 0x7f99b20f4750>




```python
#Create the testing data set
#Create a new array containing scaled values from index 1543 to 2002 
test_data = scaled_data[training_data_len - 60: , :]
#Create the data sets x_test and y_test
x_test = []
y_test = dataset[training_data_len:, :]
for i in range(60, len(test_data)):
    x_test.append(test_data[i-60:i, 0])
    
# Convert the data to a numpy array
x_test = np.array(x_test)

# Reshape the data
x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1 ))

# Get the models predicted price values 
predictions = model.predict(x_test)
predictions = scaler.inverse_transform(predictions)

# Get the root mean squared error (RMSE)
rmse = np.sqrt(np.mean(((predictions - y_test) ** 2)))
rmse

# the data points vary by 1.59 points from the regression line 
```




    1.580921659168895



#### Final CISCO Model 


```python
# Plot the data
train = data[:training_data_len]
valid = data[training_data_len:]
valid['Predictions'] = predictions
# Visualize the data
plt.figure(figsize=(16,8))
plt.title('Model')
plt.xlabel('Date', fontsize=18)
plt.ylabel('Close Price USD ($)', fontsize=18)
plt.plot(train['Close'])
plt.plot(valid[['Close', 'Predictions']])
plt.legend(['Train', 'Val', 'Predictions'], loc='lower right')
plt.show()
```


![png](output_228_0.png)


#### Valid and Predicted Prices RMSE = 1.59 (CISCO)


```python
#Show the valid and predicted prices
valid
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
      <th>Predictions</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-12-21</th>
      <td>41.849998</td>
      <td>45.636856</td>
    </tr>
    <tr>
      <th>2018-12-24</th>
      <td>40.279999</td>
      <td>45.007465</td>
    </tr>
    <tr>
      <th>2018-12-26</th>
      <td>42.470001</td>
      <td>44.260315</td>
    </tr>
    <tr>
      <th>2018-12-27</th>
      <td>42.910000</td>
      <td>43.798897</td>
    </tr>
    <tr>
      <th>2018-12-28</th>
      <td>42.770000</td>
      <td>43.561073</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-09-11</th>
      <td>39.880001</td>
      <td>41.610111</td>
    </tr>
    <tr>
      <th>2020-09-14</th>
      <td>40.369999</td>
      <td>41.335995</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>40.599998</td>
      <td>41.175472</td>
    </tr>
    <tr>
      <th>2020-09-16</th>
      <td>40.419998</td>
      <td>41.110638</td>
    </tr>
    <tr>
      <th>2020-09-17</th>
      <td>40.285000</td>
      <td>41.076744</td>
    </tr>
  </tbody>
</table>
<p>438 rows × 2 columns</p>
</div>



The model for Cisco (High ESG Tech) campany seems to be very strong with only a RMSE of 1.59

The predicted values are slighly over the test data. The model predicts that 2021 prices will start to level off but remain high. 

#### Predicting the closing price stock price of AMAZON 


```python
#Get the stock quote
df = DataReader('AMZN', data_source='yahoo', start='2012-01-01', end=datetime.now())
#Show teh data
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-01-03</th>
      <td>179.479996</td>
      <td>175.550003</td>
      <td>175.889999</td>
      <td>179.029999</td>
      <td>5110800</td>
      <td>179.029999</td>
    </tr>
    <tr>
      <th>2012-01-04</th>
      <td>180.500000</td>
      <td>176.070007</td>
      <td>179.210007</td>
      <td>177.509995</td>
      <td>4205200</td>
      <td>177.509995</td>
    </tr>
    <tr>
      <th>2012-01-05</th>
      <td>178.250000</td>
      <td>174.050003</td>
      <td>175.940002</td>
      <td>177.610001</td>
      <td>3809100</td>
      <td>177.610001</td>
    </tr>
    <tr>
      <th>2012-01-06</th>
      <td>184.649994</td>
      <td>177.500000</td>
      <td>178.070007</td>
      <td>182.610001</td>
      <td>7008400</td>
      <td>182.610001</td>
    </tr>
    <tr>
      <th>2012-01-09</th>
      <td>184.369995</td>
      <td>177.000000</td>
      <td>182.759995</td>
      <td>178.559998</td>
      <td>5056900</td>
      <td>178.559998</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-09-11</th>
      <td>3217.340088</td>
      <td>3083.979980</td>
      <td>3208.689941</td>
      <td>3116.219971</td>
      <td>5094000</td>
      <td>3116.219971</td>
    </tr>
    <tr>
      <th>2020-09-14</th>
      <td>3187.389893</td>
      <td>3096.000000</td>
      <td>3172.939941</td>
      <td>3102.969971</td>
      <td>4529600</td>
      <td>3102.969971</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>3175.020020</td>
      <td>3108.919922</td>
      <td>3136.159912</td>
      <td>3156.129883</td>
      <td>4021500</td>
      <td>3156.129883</td>
    </tr>
    <tr>
      <th>2020-09-16</th>
      <td>3187.239990</td>
      <td>3074.149902</td>
      <td>3179.989990</td>
      <td>3078.100098</td>
      <td>4512200</td>
      <td>3078.100098</td>
    </tr>
    <tr>
      <th>2020-09-17</th>
      <td>3029.431885</td>
      <td>2981.800049</td>
      <td>3009.250000</td>
      <td>3008.000000</td>
      <td>2858344</td>
      <td>3008.000000</td>
    </tr>
  </tbody>
</table>
<p>2192 rows × 6 columns</p>
</div>




```python
plt.figure(figsize=(16,8))
plt.title('Close Price History')
plt.plot(df['Close'])
plt.xlabel('Date', fontsize=18)
plt.ylabel('Close Price USD ($)', fontsize=18)
plt.show()
```


![png](output_234_0.png)


Amazon is a much larger company than Cisco with a much higher stock price. The growth of the closing price has been consistent and in the middle of 2018 there was a big increase with a bigger incease in March 2020. Which highlights the dominance of the company. 

#### LSMT Model for AMAZON


```python
#Create a new dataframe with only the 'Close column
data = df.filter(['Close'])
#Convert the dataframe to a numpy array
dataset = data.values
#Get the number of rows to train the model on
training_data_len = int(np.ceil( len(dataset) * .8 ))

training_data_len
```


```python
#Scale the data
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler(feature_range=(0,1))
scaled_data = scaler.fit_transform(dataset)

scaled_data
```


```python
#Create the training data set
#Create the scaled training data set
train_data = scaled_data[0:int(training_data_len), :]
#Split the data into x_train and y_train data sets
x_train = []
y_train = []

for i in range(60, len(train_data)):
    x_train.append(train_data[i-60:i, 0])
    y_train.append(train_data[i, 0])
    if i<= 61:
        print(x_train)
        print(y_train)
        print()
        
# Convert the x_train and y_train to numpy arrays 
x_train, y_train = np.array(x_train), np.array(y_train)

#Reshape the data
x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))
# x_train.shape
```


```python
from keras.models import Sequential
from keras.layers import Dense, LSTM

#Build the LSTM model
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape= (x_train.shape[1], 1)))
model.add(LSTM(50, return_sequences= False))
model.add(Dense(25))
model.add(Dense(1))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

#Train the model
model.fit(x_train, y_train, batch_size=1, epochs=1)
```

    Epoch 1/1
    1694/1694 [==============================] - 301s 178ms/step - loss: 5.3764e-04





    <keras.callbacks.callbacks.History at 0x7f9aa271e990>




```python
#Create the testing data set
#Create a new array containing scaled values from index 1543 to 2002 
test_data = scaled_data[training_data_len - 60: , :]
#Create the data sets x_test and y_test
x_test = []
y_test = dataset[training_data_len:, :]
for i in range(60, len(test_data)):
    x_test.append(test_data[i-60:i, 0])
    
# Convert the data to a numpy array
x_test = np.array(x_test)

# Reshape the data
x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1 ))

# Get the models predicted price values 
predictions = model.predict(x_test)
predictions = scaler.inverse_transform(predictions)

# Get the root mean squared error (RMSE)
rmse = np.sqrt(np.mean(((predictions - y_test) ** 2)))
rmse
```




    166.61108814557065



#### Final AMAZON Model 


```python
# Plot the data
train = data[:training_data_len]
valid = data[training_data_len:]
valid['Predictions'] = predictions
# Visualize the data
plt.figure(figsize=(16,8))
plt.title('Model')
plt.xlabel('Date', fontsize=18)
plt.ylabel('Close Price USD ($)', fontsize=18)
plt.plot(train['Close'])
plt.plot(valid[['Close', 'Predictions']])
plt.legend(['Train', 'Val', 'Predictions'], loc='lower right')
plt.show()
```


![png](output_243_0.png)


#### Valid and Predicted Prices RMSE = 166.61 (AMAZON)


```python
#Show the valid and predicted prices
valid
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Close</th>
      <th>Predictions</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-12-21</th>
      <td>1377.449951</td>
      <td>1698.242432</td>
    </tr>
    <tr>
      <th>2018-12-24</th>
      <td>1343.959961</td>
      <td>1663.612427</td>
    </tr>
    <tr>
      <th>2018-12-26</th>
      <td>1470.900024</td>
      <td>1624.641602</td>
    </tr>
    <tr>
      <th>2018-12-27</th>
      <td>1461.640015</td>
      <td>1600.918823</td>
    </tr>
    <tr>
      <th>2018-12-28</th>
      <td>1478.020020</td>
      <td>1585.685913</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2020-09-11</th>
      <td>3116.219971</td>
      <td>3558.483398</td>
    </tr>
    <tr>
      <th>2020-09-14</th>
      <td>3102.969971</td>
      <td>3522.757324</td>
    </tr>
    <tr>
      <th>2020-09-15</th>
      <td>3156.129883</td>
      <td>3487.056152</td>
    </tr>
    <tr>
      <th>2020-09-16</th>
      <td>3078.100098</td>
      <td>3460.750732</td>
    </tr>
    <tr>
      <th>2020-09-17</th>
      <td>3008.000000</td>
      <td>3432.453369</td>
    </tr>
  </tbody>
</table>
<p>438 rows × 2 columns</p>
</div>



Amazon has low ESG ratings and is a much larger company than Cisco which means comparing these two companies requries a more complex model and controlling of variables. 

The RMSE is 166.61 which is larger than Cico's but this is due to Amazon's high stock price. The model overall performs well. The prediction values is higher than the test data but starts to merge in March 2020. The model predicts that in 2021 the stock price will go down a little and remain high. 

#### Conclusion 

Limitations 
- It is difficult to predict stock price based on historical data
- Omitted variable bias and many Confounders
- Reverse Causality 
- Limited access to stock data API means it is more difficult to compare companies in similar size and industry 

ESG policies and values are pivatol to changing attitudes and consumer habits towards a more sustainable future. The result shows that ESG companies in the ftse 100 were more resiliant however, prices for top and worst companies are starting to level off also these graphs did not include tech companies. When we look at tech companies in the S&P 500 ESG ranking did not make a difference to stock price. Technology companies regardless of ESG ranking were more resiliant during the pandemic this could be due to market monopoly and stringent government policies which allowed tech companies to dominate changing habits during the pandemic. Overall, the result shows that technology companies are growing and stock price will remain high. This means that technology companies have more of a responsibility to become more sustainable and eviromentally friendly as more people rely on tech companies it is very important that ESG is taken seriously by tech companies and ESG regulations should be updated by the government to reflect changing consumer habits and to achieve UK sustainability targets. 

---

## Final Conclusion 

This report examined how individual and aggregate habits have changed and how this affects UK’s Sustainability targets. We have identified that for individuals’ lockdown restrictions caused public transport and road vehicle use to decline. This could contribute to improving air quality and stimulating engagement with the natural environment. For businesses and investors, a rise in ESG firms reflect these changes in consumer habits and further contribute to mitigating climate change and using resources more sustainably. ESG companies proved to be resilient during this pandemic with the exception of technology companies who outperformed regardless of ESG rating. However, although we have seen a sharp change in attitudes and habits in the short term, there is question to whether these changes are permanent or just a reflection of our current period. 
